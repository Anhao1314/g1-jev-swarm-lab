import csv,json,subprocess,hashlib
from pathlib import Path
r=Path(__file__).parent; repo=Path(r'D:\work\g1-jev-swarm-lab')
prefix='experiments/m2/post_halt_hold_qualification_001/'
for n in ['report.md','derived/summary.json']:
 b=subprocess.check_output(['git','show','d0a04f4:'+prefix+n],cwd=repo);p=r/'comparison_source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
ours=json.loads((r/'independent_result_before_comparison.json').read_text())['results']; main=json.loads((r/'comparison_source/derived/summary.json').read_text());diff=[];window=[]
for cell in main['cells']:
 name=cell['cell_id'];a=ours[name];checks={'first_crossing_stop_step':cell['first_crossing']['first_qualifying_stop_step'],'rolling_max_mps':cell['max_rolling_mean_mps'],'endpoint_speed_mps':cell['final_speed_mps'],'xy_path_m':cell['xy_path_length_m'],'net_xy_displacement_m':cell['xy_net_displacement_m'],'instantaneous_peak_mps':cell['max_instantaneous_speed_mps']}
 for k,v in checks.items():
  if abs(a[k]-v)>1e-12:diff.append({'cell':name,'metric':k,'independent':a[k],'main':v})
 outcome=json.loads((r/'restored'/name/'outcome.json').read_text());csvrows=list(csv.DictReader((r/(name+'_windows.csv')).open()))
 d=max(abs(float(x['rolling_500_mean_mps'])-y) for x,y in zip(csvrows,outcome['rolling_mean_speed_mps']))
 assert len(csvrows)==len(outcome['rolling_mean_speed_mps'])==1000
 window.append({'cell':name,'all_windows':1000,'max_abs_difference':d})
print(diff,window)
(r/'comparison.json').write_text(json.dumps({'numeric_differences':diff,'all_window_comparisons':window,'interpretation':'Main PASS is appropriately bounded; no scientific contradiction found. Add instantaneous exceedance counts/joint motion and distinguish Git blob vs CRLF checkout hashes.'},indent=2)+'\n',encoding='utf8')
