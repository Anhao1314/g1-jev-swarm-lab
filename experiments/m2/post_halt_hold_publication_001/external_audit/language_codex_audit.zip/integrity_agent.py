import json,hashlib,subprocess,pathlib,zipfile,urllib.request
A=pathlib.Path(r'D:\work\g1-m25a-final-audit-20261009'); R=pathlib.Path(r'D:\work\g1-jev-swarm-lab')
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(c,p):return subprocess.check_output(['git','show',c+':'+p],cwd=R,stderr=subprocess.DEVNULL)
def checkmap(m,c):
 out=[]
 for p,h in m.items():
  try:b=blob(c,p);where='git'
  except subprocess.CalledProcessError:
   if (R/p).is_file():b=(R/p).read_bytes();where='workingtree_external_unversioned'
   else:out.append({'path':p,'expected':h,'status':'UNAVAILABLE'});continue
  out.append({'path':p,'expected':h,'actual':sha(b),'status':'MATCH' if sha(b)==h else 'MISMATCH','origin':where})
 return out
raw=json.loads((A/'raw_manifest.json').read_text()); z=zipfile.ZipFile(A/'original.zip'); names=z.namelist(); rows=[]
for p,v in raw['files'].items():
 b=z.read(p); rb=(A/'restored'/p).read_bytes(); rows.append({'path':p,'zip_sha256':sha(b),'restored_sha256':sha(rb),'expected':v['sha256'],'bytes':len(b),'status':'MATCH' if sha(b)==sha(rb)==v['sha256'] and len(b)==v['bytes'] else 'MISMATCH'})
result={'archive_sha256':sha((A/'original.zip').read_bytes()),'archive_bytes':(A/'original.zip').stat().st_size,'archive_matches':sha((A/'original.zip').read_bytes())==raw['archive']['sha256'],'file_count':len(rows),'zip_member_count':len(names),'extra_zip_members':sorted(set(names)-set(raw['files'])),'raw_files':rows}
for name,key in [('source_manifest','files'),('freeze_manifest','sha256'),('source_binding','sha256')]:
 result[name]=checkmap(json.loads((A/(name+'.json')).read_text())[key],'d7fcb76')
result['archive_git_bytes_match']=blob('d0a04f4','experiments/m2/post_halt_hold_qualification_001/raw/campaign_001.zip')==(A/'original.zip').read_bytes()
result['pr_heads']={}
for n in [14,17]:
 try:
  d=json.load(urllib.request.urlopen(urllib.request.Request('https://api.github.com/repos/Anhao1314/g1-jev-swarm-lab/pulls/'+str(n),headers={'User-Agent':'M25A-independent-integrity-audit'}),timeout=15));result['pr_heads'][str(n)]={'head':d['head']['sha'],'base':d['base']['sha'],'state':d['state'],'merged':d['merged']}
 except Exception as e:result['pr_heads'][str(n)]={'unavailable':type(e).__name__+': '+str(e)}
result['manifest_git_bindings']={}
for name,c,prefix in [('raw_manifest','d0a04f4','post_halt_hold_qualification_001'),('source_manifest','d7fcb76','post_halt_hold_design_001'),('freeze_manifest','d7fcb76','post_halt_hold_design_001'),('source_binding','d7fcb76','post_halt_hold_design_001')]:
 result['manifest_git_bindings'][name]=blob(c,'experiments/m2/'+prefix+'/'+name+'.json')==(A/(name+'.json')).read_bytes()
(A/'integrity_agent.json').write_text(json.dumps(result,indent=2)+'\n');print({k:sum(vv['status']!='MATCH' for vv in result[k]) for k in ['source_manifest','freeze_manifest','source_binding']});print('raw',len(rows),'allmatch',all(v['status']=='MATCH' for v in rows)); print(result['pr_heads']);print(result['manifest_git_bindings'])
