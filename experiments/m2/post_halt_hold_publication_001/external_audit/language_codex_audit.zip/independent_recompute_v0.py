"""Independent standard-library audit. No experiment modules or physics imported."""
import argparse,csv,hashlib,json,math,subprocess,zipfile,io
from pathlib import Path
from collections import deque
ROOT=Path(__file__).resolve().parent
REPO=Path(r'D:\work\g1-jev-swarm-lab')
def read(p):return json.loads(p.read_text(encoding='utf8'))
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(ref,p):return subprocess.check_output(['git','show',ref+':'+p],cwd=REPO)
def speeds(rows):return [math.hypot(r['qvel'][0],r['qvel'][1]) for r in rows]
def rolling(v,n=500):
 return [sum(v[i-n+1:i+1])/n for i in range(n-1,len(v))]
def physical(r):
 q=r['qpos']; norm=math.sqrt(sum(v*v for v in q[3:7])); w,x,y,z=[v/norm for v in q[3:7]]
 tilt=math.degrees(math.acos(max(-1,min(1,1-2*(x*x+y*y)))))
 finite=all(math.isfinite(v) for k in ['qpos','qvel','ctrl'] for v in r[k]) and all(math.isfinite(v) for a in r['xfrc_applied'] for v in a)
 fallen=q[2]<.45 or tilt>65
 return finite,not fallen and q[2]>=.55 and tilt<=30,fallen,tilt
manifest=read(ROOT/'raw_manifest.json'); archive=(ROOT/'original.zip').read_bytes()
assert sha(archive)==manifest['archive']['sha256'] and len(archive)==manifest['archive']['bytes']
with zipfile.ZipFile(io.BytesIO(archive)) as z:
 assert set(z.namelist())==set(manifest['files']) and len(z.namelist())==43
 inventory={}
 for name,expected in manifest['files'].items():
  b=z.read(name);assert sha(b)==expected['sha256'] and len(b)==expected['bytes']
  assert (ROOT/'restored'/name).read_bytes()==b
  inventory[name]={'sha256':sha(b),'bytes':len(b),'match':True}
(ROOT/'raw_hash_verification.json').write_text(json.dumps({'zip_sha256':sha(archive),'files':inventory},indent=2)+'\n',encoding='utf8')
results={}
for spec in read(ROOT/'protocol.json')['cells_in_order']:
 name=spec['id']; folder=ROOT/'restored'/name
 native=[json.loads(x) for x in (folder/'native_incremental.jsonl').read_text().splitlines()]
 hold=[r for r in native if r['phase']=='hold']; parent=[r for r in native if r['phase']=='parent']
 entry=read(folder/'hold_entry.json');t=entry['terminal']; witness=read(folder/'witness.json');pr=read(folder/'parent_result.json')
 if name=='normal_stop_hold_control':
  stop_node=[n for n in pr['nodes'] if n.get('skill')=='stop']
  print('normal stop node keys',[(list(n),n.get('start_state',{})) for n in stop_node])
  stop_count=len(t['stop_poststep_speeds'])
  # Frozen StopSkill requires 500 samples; control has exactly 500, no earlier eligible crossing exists.
 else:
  onset=pr['physical_halt']['pre_halt_state']['simulation_time']
  stop_count=len([r for r in parent if r['time_s']>onset+1e-10])
 stop=parent[-stop_count:];sv=speeds(stop);means=rolling(sv)
 assert len(sv)==len(t['stop_poststep_speeds']) and all(abs(a-b)<1e-12 for a,b in zip(sv,t['stop_poststep_speeds']))
 first=next(i+500 for i,v in enumerate(means) if v<=.1)
 assert first==len(stop) and abs(stop[-1]['time_s']-t['stop_crossing_time_s'])<1e-10
 seed=sv[-500:];assert seed==entry['seed_speeds_mps']
 hv=speeds(hold);rr=rolling(seed+hv)[1:];assert len(hold)==1000 and len(rr)==1000
 xy=[entry['pre_first_step']['qpos'][:2]]+[r['qpos'][:2] for r in hold]
 path=sum(math.dist(a,b) for a,b in zip(xy,xy[1:]));states=[physical(r) for r in hold]
 snapkeys=['time_s','qpos','qvel','ctrl','xfrc_applied','controller_action','controller_target','controller_counter','simulation_identity','controller_identity','policy_identity','session_identity','controller_reset_calls','native_reset_calls','reset_calls','node_dispatches','executor_dispatches']
 snapshots=[t['skill_return_snapshot'],t['snapshot'],entry['pre_first_step']]
 exact=all(all(s[k]==snapshots[0][k] for k in snapkeys) for s in snapshots)
 last=parent[-1];pre=entry['pre_first_step']
 native_boundary=all(last[k]==pre[k] for k in ['qpos','qvel','ctrl','xfrc_applied','time_s']) and last['controller']['_counter']==pre['controller_counter'] and last['controller']['_action']==pre['controller_action'] and last['controller']['_target']==pre['controller_target']
 counters=all(r['controller']['_counter']==pre['controller_counter']+i+1 for i,r in enumerate(hold))
 continuity=exact and native_boundary and counters
 for k in ['simulation_identity','controller_identity','policy_identity','session_identity','controller_reset_calls','native_reset_calls','reset_calls','node_dispatches','executor_dispatches']:
  continuity=continuity and witness['final_snapshot'][k]==pre[k]
 hold_journal=[json.loads(x) for x in (folder/'hold_incremental.jsonl').read_text().splitlines()]
 command_zero=all(r['command_xyz_mps_radps']==[0.,0.,0.] for r in hold_journal)
 all_finite=all(x[0] for x in states);all_standing=all(x[1] for x in states);no_fall=not any(x[2] for x in states)
 checks={'all_1000_means':max(rr)<=.1,'endpoint':hv[-1]<=.1,'path':path<=.2,'finite':all_finite,'standing':all_standing,'no_fall':no_fall}
 result={'first_crossing_stop_step':first,'stop_duration_s':first*.002,'first_crossing_time_s':stop[-1]['time_s'],'first_crossing_mean_mps':means[first-500], 'prior_window_mean_mps':means[first-501] if first>500 else None,'hold_windows':len(rr),'rolling_max_mps':max(rr),'rolling_min_mps':min(rr),'endpoint_speed_mps':hv[-1],'xy_path_m':path,'net_xy_displacement_m':math.dist(xy[0],xy[-1]),'max_xy_displacement_m':max(math.dist(xy[0],x) for x in xy),'instantaneous_peak_mps':max(hv),'instantaneous_over_threshold_samples':sum(v>.1 for v in hv),'hold_only_disjoint_means_mps':[sum(hv[:500])/500,sum(hv[500:])/500],'height_range_m':[min(r['qpos'][2] for r in hold),max(r['qpos'][2] for r in hold)],'tilt_max_deg':max(x[3] for x in states),'joint_speed_peak_radps':max(abs(v) for r in hold for v in r['qvel'][6:]),'checks':checks,'continuity':continuity,'commands_zero':command_zero,'all_time_steps_correct':all(abs(b['time_s']-a['time_s']-.002)<1e-10 for a,b in zip(native,native[1:])),'native_steps':len(native),'parent_native_steps':len(parent),'verdict':'HOLD_SUCCEEDED_BOUNDED_IN_THIS_STATE' if all(checks.values()) and continuity and command_zero else 'FAIL'}
 results[name]=result
 with (ROOT/(name+'_windows.csv')).open('w',newline='',encoding='utf8') as f:
  writer=csv.writer(f);writer.writerow(['step','native_time_s','qvel_planar_speed_mps','rolling_500_mean_mps','height_m','tilt_deg'])
  writer.writerows((i+1,r['time_s'],hv[i],rr[i],r['qpos'][2],states[i][3]) for i,r in enumerate(hold))
# Freeze independent verdict before opening main report.
(ROOT/'independent_result_before_comparison.json').write_text(json.dumps({'scientific_verdict':'BOUNDED_THREE_CELL_QUALIFICATION_CONFIRMED_NO_GENERAL_SAFETY_OR_AUTHORITY_CLAIM','protocol_sha256':sha((ROOT/'protocol.json').read_bytes()),'zip_sha256':sha(archive),'results':results,'physics_calls':0,'policy_calls':0},indent=2)+'\n',encoding='utf8')
print(json.dumps(results,indent=2))
