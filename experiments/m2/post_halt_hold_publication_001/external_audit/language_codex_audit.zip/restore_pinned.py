"""Restore only pinned Git evidence to a NEW directory; standard library only."""
import argparse,hashlib,io,json,subprocess,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--output',required=True);a=p.parse_args();r=Path(a.output)
if r.exists():raise SystemExit('Refusing overwrite: output must not exist')
def b(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=a.repo)
pre='experiments/m2/post_halt_hold_qualification_001/'
z=b('d0a04f46ac05f57abb85470905f021b139d485cd',pre+'raw/campaign_001.zip');manifest=json.loads(b('d0a04f4',pre+'raw_manifest.json'))
assert hashlib.sha256(z).hexdigest()==manifest['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(z)) as archive:
 assert len(archive.namelist())==len(set(archive.namelist()))==43 and set(archive.namelist())==set(manifest['files'])
 verified=[]
 for n in archive.namelist():
  target=(r/'restored'/n).resolve();assert target.is_relative_to((r/'restored').resolve())
  data=archive.read(n);assert len(data)==manifest['files'][n]['bytes'] and hashlib.sha256(data).hexdigest()==manifest['files'][n]['sha256'];verified.append((target,data))
 r.mkdir(parents=True)
 for target,data in verified:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
(r/'original.zip').write_bytes(z)
for n in ['raw_manifest.json','evidence_manifest.json','campaign_receipt.json','execution_receipt.json']:(r/n).write_bytes(b('d0a04f4',pre+n))
for n in ['protocol.json','freeze_manifest.json','source_manifest.json','source_binding.json','design.md']:(r/n).write_bytes(b('d7fcb76','experiments/m2/post_halt_hold_design_001/'+n))
print('Verified 43 files; no physics, policy or frozen-source edits.')
