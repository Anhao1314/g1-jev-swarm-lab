import json,re,os,subprocess,time,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
session=Path(r'C:\Users\Administrator\.codex\sessions\2026\10\07\rollout-2026-10-07T18-42-34-01a115f5-38be-7580-a754-c1556e2f1aa7.jsonl')
key=None
for line in session.read_text(encoding='utf-8').splitlines():
 obj=json.loads(line);p=obj.get('payload',{})
 if p.get('role')!='user':continue
 txt='\n'.join(x.get('text','') for x in p.get('content',[]) if isinstance(x,dict))
 if 'api.deepseek.com' in txt and 'send_user_message_question_reply' in txt:
  m=re.findall(r'(?<![\w-])sk-[A-Za-z0-9_-]+',txt)
  if len(m)==1:key=m[0]
if not key:raise SystemExit('CREDENTIAL_UNAVAILABLE')
env=os.environ.copy();env['DEEPSEEK_API_KEY']=key;env['CODEX_HOME']=r'D:\webcodex\g1-deepseek-pilot-evidence\20261012-0024\isolated-codex-home'
cli=r'C:\Users\Administrator\AppData\Local\OpenAI\Codex\bin\2e5e00daee91c61d\codex.exe'
args=[cli,'exec','--ignore-user-config','--ignore-rules','--ephemeral','--json','--dangerously-bypass-approvals-and-sandbox','--skip-git-repo-check','--disable','plugins','--disable','remote_plugin','--disable','skill_search','--disable','recommended_plugins','-C',r'\\wsl.localhost\G1-RL-Ubuntu\home\g1rl\g1-rl\worktrees\t2a-supervisor-integration','-m','deepseek-flash']
for c in ['model_provider="deepseek_helper"','model_providers.deepseek_helper.name="DeepSeek V4.1 Flash engineering helper"','model_providers.deepseek_helper.base_url="https://api.deepseek.com/v1"','model_providers.deepseek_helper.env_key="DEEPSEEK_API_KEY"','model_providers.deepseek_helper.wire_api="responses"','model_providers.deepseek_helper.request_max_retries=0','model_providers.deepseek_helper.stream_max_retries=0','model_providers.deepseek_helper.stream_idle_timeout_ms=90000']:
 args+=['-c',c]
args+=['-']
(root/'invocation.json').write_text(json.dumps({'argv':args,'base_head':'82a2959272aafccb46cbdd05e077daa747c5d0bd','model_id':'deepseek-flash','provider':'https://api.deepseek.com/v1','model_version_binding':'https://api-docs.deepseek.com/quick_start/pricing','prompt_sha256':hashlib.sha256((root/'delegation-prompt.txt').read_bytes()).hexdigest(),'credential':'transient process environment; no secret identity retained','timeout_seconds':540},indent=2),encoding='utf-8')
started=time.monotonic();p=subprocess.Popen(args,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace')
(root/'process.json').write_text(json.dumps({'owned_cli_pid':p.pid,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}),encoding='utf-8')
status='COMPLETED'
try:out,err=p.communicate((root/'delegation-prompt.txt').read_text(encoding='utf-8'),timeout=540)
except subprocess.TimeoutExpired:
 status='TIMEOUT_STOPPED';subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True);out,err=p.communicate()
out=out.replace(key,'[REDACTED]');err=err.replace(key,'[REDACTED]')
(root/'deepseek-events.jsonl').write_text(out,encoding='utf-8');(root/'deepseek-stderr.log').write_text(err,encoding='utf-8')
commands=[];messages=[];usage=None
for line in out.splitlines():
 try:event=json.loads(line)
 except ValueError:continue
 if event.get('type')=='turn.completed':usage=event.get('usage')
 item=event.get('item',{})
 if event.get('type')=='item.completed' and item.get('type')=='command_execution':commands.append(item)
 if event.get('type')=='item.completed' and item.get('type')=='agent_message':messages.append(item.get('text',''))
receipt={'status':status,'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-started,3),'reported_usage':usage,'api_actual_cost':'NOT_REPORTED','completed_command_count':len(commands)}
(root/'delegation-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');(root/'completed-tool-records.json').write_text(json.dumps(commands,indent=2,ensure_ascii=False),encoding='utf-8');(root/'deepseek-final.txt').write_text('\n\n'.join(messages),encoding='utf-8')
env.pop('DEEPSEEK_API_KEY',None);key=None
print(json.dumps(receipt));print('\n\n'.join(messages));print(err[-2000:])
