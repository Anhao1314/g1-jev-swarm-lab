"""Nonphysical T2a supervisor-delegation checks: synthetic Linux processes only.

No physics, policy load, checkpoint, prediction or real backend import. The Worker
import boundary is proven with poisoned synthetic modules and the trust boundary with
real synthetic processes, not with mock claims of success.
"""
import hashlib,importlib.util,json,os,subprocess,sys,textwrap,time
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
HERE=ROOT/'experiments/rl/g1_ppo_t2a_frozen_comparison_001'
RUN=HERE/'run.py'
SUP=HERE/'supervision.py'
_spec=importlib.util.spec_from_file_location('t2_supervision',SUP);sup=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(sup)
_rspec=importlib.util.spec_from_file_location('t2_run_under_test',RUN);run=importlib.util.module_from_spec(_rspec);_rspec.loader.exec_module(run)


def _sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def _head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()


PRELUDE=("import importlib.util,sys,os,subprocess,time\n"
         "spec=importlib.util.spec_from_file_location('sup',"+repr(str(SUP))+")\n"
         "sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)\n"
         "fd=int(sys.argv[sys.argv.index('--supervisor-fd')+1])\n"
         "def _body():\n")
TAIL=("try:\n    _body()\nexcept sup.DelegationRefused as exc:\n"
      "    print('WORKER_REFUSED:'+str(exc),file=sys.stderr)\n    raise SystemExit(76)\n")
POSITIVE_BODY=("sup.consume_delegation(fd,run_identity=sys.argv[1],readiness_sha256=sys.argv[2],"
               "execution_head=sys.argv[3],protocol_sha256=sys.argv[4])\nprint('SYNTHETIC_WORKER_OK')\n")
PARTIAL_BODY=POSITIVE_BODY+"sys.exit(3)\n"


def _worker(tmp_path,name,body,root,*expected):
    script=tmp_path/name;script.write_text(PRELUDE+textwrap.indent(body,'    ')+TAIL)
    return [sys.executable,str(script),str(root),*expected]


def _poisoned_env(tmp_path,modules=('numpy','torch')):
    poison=tmp_path/'poison';poison.mkdir(exist_ok=True);marker=tmp_path/'forbidden-import'
    for module in modules:
        (poison/f'{module}.py').write_text("import pathlib\npathlib.Path("+repr(str(marker))
                                           +").write_text('imported')\nraise ImportError('poisoned '+"
                                           +repr(module)+"')\n")
    env={**os.environ,'PYTHONPATH':str(poison)+os.pathsep+str(ROOT/'src')}
    return env,marker


def test_supervised_synthetic_worker_positive(tmp_path):
    root=tmp_path/'run'
    result=sup.supervise(_worker(tmp_path,'positive.py',POSITIVE_BODY,root,'R0','H0','P0'),root,30,
                         run_identity=root,readiness_sha256='R0',execution_head='H0',protocol_sha256='P0')
    assert result['native_exitcode']==0 and result['interrupted'] is None
    assert 'SYNTHETIC_WORKER_OK' in (root/'worker.stdout.raw').read_text()
    assert (root/'worker.stderr.raw').read_text()==''
    assert json.loads((root/'process-receipt.json').read_text())['native_exitcode']==0
    assert not (root/'delegation.token').exists() and (root/'delegation.token.consumed').exists()


def test_supervisor_main_reaches_worker_only_after_preflight(tmp_path):
    root=tmp_path/'campaign';manifest=tmp_path/'manifest.json';manifest.write_text('{}')
    seen=[]
    def verifier(path,expected):seen.append((str(path),expected));return {'execution_head':'H0','protocol_sha256':'P0'}
    worker_argv=_worker(tmp_path,'positive.py',POSITIVE_BODY,root,'R0','H0','P0')
    with pytest.raises(SystemExit) as info:
        run.main([str(root),str(manifest),'R0','--execute-owner-approved'],verifier=verifier,worker_argv=worker_argv)
    assert info.value.code==0
    assert seen==[(str(manifest),'R0')] and (root/'once.claim').exists()
    assert (root/'delegation.token.consumed').exists() and 'SYNTHETIC_WORKER_OK' in (root/'worker.stdout.raw').read_text()


def test_preflight_failure_creates_no_run_side_effects(tmp_path):
    root=tmp_path/'campaign'
    def verifier(path,expected):raise RuntimeError('wrong_execution_head')
    with pytest.raises(RuntimeError,match='wrong_execution_head'):
        run.main([str(root),str(tmp_path/'m.json'),'R0','--execute-owner-approved'],verifier=verifier,
                 worker_argv=[sys.executable,'-c','raise SystemExit(0)'])
    assert not root.exists()


@pytest.mark.parametrize('case',['readiness','head'])
def test_real_readiness_preflight_blocks_before_side_effects(tmp_path,case):
    root=tmp_path/'campaign';manifest=tmp_path/'manifest.json'
    if case=='readiness':
        manifest.write_text('{}');expected='0'*64;reason='readiness_mismatch'
    else:
        manifest.write_text(json.dumps({'execution_head':'0'*40}));expected=_sha(manifest);reason='wrong_execution_head'
    with pytest.raises(RuntimeError,match=reason):
        run.main([str(root),str(manifest),expected,'--execute-owner-approved'])
    assert not root.exists()


def test_real_source_preflight_blocks_before_side_effects(tmp_path):
    # The live worktree carries uncommitted implementation changes, so a manifest that
    # matches the real HEAD must still be refused at the source-integrity gate.
    root=tmp_path/'campaign';manifest=tmp_path/'manifest.json'
    manifest.write_text(json.dumps({'execution_head':_head()}))
    with pytest.raises((RuntimeError,KeyError)):
        run.main([str(root),str(manifest),_sha(manifest),'--execute-owner-approved'])
    assert not root.exists()


def test_direct_worker_rejected_before_backend_imports(tmp_path):
    env,marker=_poisoned_env(tmp_path)
    p=subprocess.run([sys.executable,'-B',str(RUN),str(tmp_path/'run'),str(tmp_path/'m.json'),'0'*64,'--worker-owner-approved'],
                     capture_output=True,text=True,env=env,timeout=30)
    assert p.returncode==76 and 'WORKER_REFUSED:supervisor_delegation_required' in p.stderr
    assert not marker.exists() and not (tmp_path/'run').exists()


def test_argv_env_or_empty_context_alone_never_qualifies(tmp_path):
    root=tmp_path/'run'
    env={**os.environ,'G1_T2A_SUPERVISOR_DELEGATION':json.dumps({'protocol':sup.VERSION}),'PYTHONPATH':str(ROOT/'src')}
    p=subprocess.run([sys.executable,'-B',str(RUN),str(root),str(tmp_path/'m.json'),'0'*64,'--worker-owner-approved'],
                     capture_output=True,text=True,env=env,timeout=30)
    assert p.returncode==76 and 'supervisor_delegation_required' in p.stderr and not root.exists()
    read_fd,write_fd=os.pipe();os.close(write_fd)
    try:
        p=subprocess.run([sys.executable,'-B',str(RUN),str(root),str(tmp_path/'m.json'),'0'*64,'--worker-owner-approved',
                          '--supervisor-fd',str(read_fd)],capture_output=True,text=True,env=env,pass_fds=(read_fd,),timeout=30)
    finally:
        os.close(read_fd)
    assert p.returncode==76 and 'malformed_delegation' in p.stderr and not root.exists()


def test_supervisor_without_operator_approval_creates_nothing(tmp_path):
    env,marker=_poisoned_env(tmp_path)
    p=subprocess.run([sys.executable,'-B',str(RUN),str(tmp_path/'run'),str(tmp_path/'m.json'),'0'*64],
                     capture_output=True,text=True,env=env,timeout=30)
    assert p.returncode!=0 and 'OWNER_CONFIRMATION_REQUIRED_BEFORE_PHYSICS' in p.stderr
    assert not (tmp_path/'run').exists() and not marker.exists()


@pytest.mark.parametrize('field,reason',[('readiness_sha256','readiness_mismatch'),('execution_head','execution_head_mismatch'),
                                         ('protocol_sha256','protocol_mismatch')])
def test_genuine_supervision_refuses_mismatched_binding(tmp_path,field,reason):
    root=tmp_path/'run';kwargs={'run_identity':root,'readiness_sha256':'R0','execution_head':'H0','protocol_sha256':'P0'}
    kwargs[field]='drift'
    result=sup.supervise(_worker(tmp_path,'positive.py',POSITIVE_BODY,root,'R0','H0','P0'),root,30,**kwargs)
    assert result['native_exitcode']==76 and result['interrupted'] is None
    assert 'WORKER_REFUSED:'+reason in (root/'worker.stderr.raw').read_text()
    assert (root/'delegation.token').exists() and not (root/'delegation.token.consumed').exists()


def test_wrong_run_identity_is_refused(tmp_path):
    root=tmp_path/'run';other=tmp_path/'other'
    result=sup.supervise(_worker(tmp_path,'positive.py',POSITIVE_BODY,root,'R0','H0','P0'),root,30,
                         run_identity=other,readiness_sha256='R0',execution_head='H0',protocol_sha256='P0')
    assert result['native_exitcode']==76 and 'WORKER_REFUSED:run_identity_mismatch' in (root/'worker.stderr.raw').read_text()
    assert (root/'delegation.token').exists()


def test_indirect_descendant_cannot_consume_the_delegation(tmp_path):
    body=("os.set_inheritable(fd,True)\n"
          "child=subprocess.run([sys.executable,"+repr(str(RUN))+",sys.argv[1],sys.argv[2],sys.argv[3],"
          "'--worker-owner-approved','--supervisor-fd',str(fd)],pass_fds=(fd,))\n"
          "sys.exit(child.returncode)\n")
    root=tmp_path/'run';manifest=tmp_path/'m.json'
    result=sup.supervise(_worker(tmp_path,'launcher.py',body,root,str(manifest),'R0'),root,30,run_identity=root,
                         readiness_sha256='R0',execution_head=_head(),protocol_sha256=_sha(HERE/'protocol.json'))
    assert result['native_exitcode']==76
    stderr=(root/'worker.stderr.raw').read_text()
    assert 'WORKER_REFUSED:' in stderr and ('worker_identity_mismatch' in stderr or 'parent_identity_mismatch' in stderr)
    assert (root/'delegation.token').exists()


def test_watchdog_kills_supervised_worker_and_descendants(tmp_path):
    body=("descendant=subprocess.Popen([sys.executable,'-c','import time;time.sleep(300)'])\n"
          "open(sys.argv[1]+'/descendant.pid','w').write(str(descendant.pid))\n"
          "sup.consume_delegation(fd,run_identity=sys.argv[1],readiness_sha256=sys.argv[2],execution_head=sys.argv[3],"
          "protocol_sha256=sys.argv[4])\ntime.sleep(300)\n")
    root=tmp_path/'run'
    result=sup.supervise(_worker(tmp_path,'slow.py',body,root,'R0','H0','P0'),root,1,run_identity=root,
                         readiness_sha256='R0',execution_head='H0',protocol_sha256='P0')
    assert result['interrupted']=='wall_clock_watchdog'
    for pid in (result['pid'],int((root/'descendant.pid').read_text())):
        for _ in range(200):
            try:os.kill(pid,0)
            except OSError:break
            time.sleep(.05)
        else:pytest.fail(f'process {pid} survived supervisor termination')


def test_partial_failure_preserves_logs_and_receipt(tmp_path):
    root=tmp_path/'run'
    result=sup.supervise(_worker(tmp_path,'partial.py',PARTIAL_BODY,root,'R0','H0','P0'),root,30,run_identity=root,
                         readiness_sha256='R0',execution_head='H0',protocol_sha256='P0')
    assert result['native_exitcode']==3 and result['interrupted'] is None
    assert 'SYNTHETIC_WORKER_OK' in (root/'worker.stdout.raw').read_text()
    assert json.loads((root/'process-receipt.json').read_text())['native_exitcode']==3
    assert (root/'delegation.token.consumed').exists()


def test_delegation_is_one_shot_and_replay_is_refused(tmp_path):
    root=tmp_path/'replay';root.mkdir()
    nonce=os.urandom(16).hex();token=root/sup.TOKEN_NAME;token.write_text(nonce)
    payload={'protocol':sup.VERSION,'run_id':str(root.resolve()),'readiness_sha256':'R0','execution_head':'H0',
             'protocol_sha256':'P0','nonce':nonce,'token':str(token),'issued_unix':time.time(),
             'supervisor':sup.proc_identity(os.getppid()),'worker':sup.proc_identity()}
    pipe=lambda: _pipe(payload)
    delegation=sup.consume_delegation(pipe(),run_identity=root,readiness_sha256='R0',execution_head='H0',protocol_sha256='P0')
    assert sup.is_live_delegation(delegation) and not token.exists() and (root/(sup.TOKEN_NAME+sup.CONSUMED_SUFFIX)).exists()
    with pytest.raises(sup.DelegationRefused,match='delegation_replayed_or_absent'):
        sup.consume_delegation(pipe(),run_identity=root,readiness_sha256='R0',execution_head='H0',protocol_sha256='P0')


def test_stale_or_self_constructed_delegation_is_refused(tmp_path):
    root=tmp_path/'stale';root.mkdir();token=root/sup.TOKEN_NAME
    nonce=os.urandom(16).hex();token.write_text(nonce)
    payload={'protocol':sup.VERSION,'run_id':str(root.resolve()),'readiness_sha256':'R0','execution_head':'H0',
             'protocol_sha256':'P0','nonce':nonce,'token':str(token),'issued_unix':time.time()-100000.,
             'supervisor':sup.proc_identity(os.getppid()),'worker':sup.proc_identity()}
    with pytest.raises(sup.DelegationRefused,match='stale_delegation'):
        sup.consume_delegation(_pipe(payload),run_identity=root,readiness_sha256='R0',execution_head='H0',protocol_sha256='P0')
    assert token.exists()
    with pytest.raises(sup.DelegationRefused,match='delegation_construction_forbidden'):sup.Delegation({},object())
    assert not sup.is_live_delegation({'protocol':sup.VERSION})


def test_execute_requires_a_live_supervisor_delegation(tmp_path):
    for delegation in (None,{'protocol':sup.VERSION},'g1.t2a.supervisor.v1'):
        with pytest.raises(RuntimeError,match='supervisor_delegation_required'):
            run.execute(tmp_path/'run',tmp_path/'m.json','0'*64,delegation)


def test_duplicate_campaign_start_is_refused(tmp_path):
    root=tmp_path/'campaign';manifest=tmp_path/'m.json';manifest.write_text('{}')
    def verifier(path,expected):return {'execution_head':'H0','protocol_sha256':'P0'}
    worker_argv=_worker(tmp_path,'positive.py',POSITIVE_BODY,root,'R0','H0','P0')
    args=[str(root),str(manifest),'R0','--execute-owner-approved']
    with pytest.raises(SystemExit) as info:run.main(args,verifier=verifier,worker_argv=worker_argv)
    assert info.value.code==0
    stdout=(root/'worker.stdout.raw').read_text()
    with pytest.raises(FileExistsError):run.main(args,verifier=verifier,worker_argv=worker_argv)
    assert (root/'worker.stdout.raw').read_text()==stdout


def _pipe(payload):
    read_fd,write_fd=os.pipe();os.write(write_fd,json.dumps(payload).encode());os.close(write_fd);return read_fd
