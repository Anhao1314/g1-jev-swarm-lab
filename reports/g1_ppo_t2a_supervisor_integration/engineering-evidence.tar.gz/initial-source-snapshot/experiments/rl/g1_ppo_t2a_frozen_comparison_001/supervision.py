"""T2a supervisor-only Worker delegation primitives. Stdlib only: no NumPy/Torch/
MuJoCo/backend import and no simulator, policy or checkpoint access.

Trust boundary (trusted same-machine serial one-shot research):
- Only the supervisor runs Readiness/source preflight, creates the campaign directory,
  the one-shot token file and the private pipe, then spawns its directly supervised Worker.
- Worker trust comes from the inherited private pipe descriptor plus the Worker's own
  kernel-observed identity (pid, start ticks, session, parent cmdline hash) and a
  one-shot token; an argv flag, environment self-report or caller-authored JSON alone
  never qualifies.
- This is an accidental-launch/ancestry guard, not production multi-user authentication.
"""
import hashlib, hmac, json, os, signal, subprocess, time
from pathlib import Path

VERSION = 'g1.t2a.supervisor.v1'
FD_FLAG = '--supervisor-fd'
TOKEN_NAME = 'delegation.token'
CONSUMED_SUFFIX = '.consumed'
MAX_DELEGATION_AGE_S = 600.0
MAX_DELEGATION_BYTES = 1 << 20


class DelegationRefused(RuntimeError):
    """A Worker invocation that does not present a live supervisor delegation."""


def _refuse(reason):
    raise DelegationRefused(reason)


_SEAL = object()


class Delegation:
    """Worker-side proof that an actual supervising process issued this run."""

    __slots__ = ('payload', '_seal')

    def __init__(self, payload, seal):
        if seal is not _SEAL:
            _refuse('delegation_construction_forbidden')
        self._seal = _SEAL
        self.payload = payload


def is_live_delegation(obj):
    return isinstance(obj, Delegation) and obj._seal is _SEAL and obj.payload.get('protocol') == VERSION


def proc_identity(pid=None):
    # Straight from /proc: avoids getsid() cross-session permission errors and binds
    # exact pid, parent, session, process start ticks and cmdline bytes.
    pid = os.getpid() if pid is None else int(pid)
    text = Path(f'/proc/{pid}/stat').read_text()
    fields = text[text.rindex(')') + 2:].split()
    return {'pid': pid, 'ppid': int(fields[1]), 'sid': int(fields[3]), 'start_ticks': int(fields[19]),
            'cmdline_sha256': hashlib.sha256(Path(f'/proc/{pid}/cmdline').read_bytes()).hexdigest()}


def _identity(pid, tries=200):
    for _ in range(tries):
        try:
            return proc_identity(pid)
        except (FileNotFoundError, ProcessLookupError, ValueError, IndexError):
            time.sleep(.005)
    _refuse('worker_identity_unavailable')


def _read_payload(fd):
    chunks = []
    while True:
        data = os.read(fd, 65536)
        if not data:
            break
        chunks.append(data)
        if sum(len(c) for c in chunks) > MAX_DELEGATION_BYTES:
            _refuse('delegation_too_large')
    try:
        payload = json.loads(b''.join(chunks).decode())
    except (ValueError, UnicodeDecodeError):
        _refuse('malformed_delegation')
    if not isinstance(payload, dict):
        _refuse('malformed_delegation')
    return payload


def _consume_token(token, nonce, run_dir):
    path = Path(token) if isinstance(token, str) else None
    if path is None or path.parent != run_dir or path.name != TOKEN_NAME:
        _refuse('delegation_token_path_mismatch')
    try:
        recorded = path.read_text().strip()
    except OSError:
        _refuse('delegation_replayed_or_absent')
    if not isinstance(nonce, str) or not hmac.compare_digest(recorded, nonce):
        _refuse('delegation_token_mismatch')
    try:
        os.rename(path, str(path) + CONSUMED_SUFFIX)
    except OSError:
        _refuse('delegation_already_consumed')


def consume_delegation(fd, *, run_identity, readiness_sha256, execution_head, protocol_sha256,
                       max_age_s=MAX_DELEGATION_AGE_S):
    """Validate and one-shot-consume the supervisor payload read from the inherited fd."""
    run_dir = Path(run_identity).resolve()
    payload = _read_payload(fd)
    if payload.get('protocol') != VERSION:
        _refuse('unsupported_delegation')
    if payload.get('run_id') != str(run_dir):
        _refuse('run_identity_mismatch')
    if payload.get('readiness_sha256') != readiness_sha256:
        _refuse('readiness_mismatch')
    if payload.get('protocol_sha256') != protocol_sha256:
        _refuse('protocol_mismatch')
    if payload.get('execution_head') != execution_head:
        _refuse('execution_head_mismatch')
    issued = payload.get('issued_unix')
    if type(issued) is not float or not 0. <= time.time() - issued <= max_age_s:
        _refuse('stale_delegation')
    supervisor = payload.get('supervisor')
    expected = payload.get('worker')
    if not isinstance(supervisor, dict) or not isinstance(expected, dict):
        _refuse('malformed_delegation_identity')
    me = proc_identity()
    if me['pid'] != expected.get('pid') or me['start_ticks'] != expected.get('start_ticks'):
        _refuse('worker_identity_mismatch')
    if me['cmdline_sha256'] != expected.get('cmdline_sha256'):
        _refuse('worker_lifetime_mismatch')
    if me['sid'] != expected.get('sid'):
        _refuse('worker_session_mismatch')
    if os.getppid() != supervisor.get('pid'):
        _refuse('parent_identity_mismatch')
    parent = proc_identity(supervisor['pid'])
    if (parent['start_ticks'] != supervisor.get('start_ticks') or parent['sid'] != supervisor.get('sid')
            or parent['cmdline_sha256'] != supervisor.get('cmdline_sha256')):
        _refuse('parent_lifetime_mismatch')
    if parent['ppid'] == me['pid']:
        _refuse('cyclic_process_ancestry')
    _consume_token(payload.get('token'), payload.get('nonce'), run_dir)
    return Delegation(payload, _SEAL)


def supervise(worker_argv, root, limit_s, *, run_identity, readiness_sha256, execution_head, protocol_sha256, poll_s=.05):
    """Run one directly supervised Worker with a private one-shot delegation.

    Retains the frozen T1 process-group termination: start_new_session=True, monotonic
    deadline, SIGTERM to the group, 250ms grace, SIGKILL to the group, then a preserved
    process receipt plus raw stdout/stderr. The only extension is pass_fds for the pipe.
    """
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    run_dir = Path(run_identity).resolve()
    nonce = os.urandom(32).hex()
    handle = os.open(root / TOKEN_NAME, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        os.write(handle, nonce.encode())
    finally:
        os.close(handle)
    read_fd, write_fd = os.pipe()
    os.set_inheritable(read_fd, True)
    started = time.monotonic()
    interrupted = None
    with (root / 'worker.stdout.raw').open('xb') as out, (root / 'worker.stderr.raw').open('xb') as err:
        worker = subprocess.Popen(list(worker_argv) + [FD_FLAG, str(read_fd)], stdout=out, stderr=err,
                                  start_new_session=True, pass_fds=(read_fd,))
        os.close(read_fd)
        payload = {'protocol': VERSION, 'run_id': str(run_dir), 'readiness_sha256': readiness_sha256,
                   'execution_head': execution_head, 'protocol_sha256': protocol_sha256, 'nonce': nonce,
                   'token': str(root / TOKEN_NAME), 'issued_unix': time.time(),
                   'supervisor': proc_identity(), 'worker': _identity(worker.pid)}
        try:
            os.write(write_fd, json.dumps(payload).encode())
        finally:
            os.close(write_fd)
        while worker.poll() is None:
            if time.monotonic() - started >= limit_s:
                interrupted = 'wall_clock_watchdog'
                os.killpg(worker.pid, signal.SIGTERM)
                time.sleep(.25)
                try:
                    os.killpg(worker.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                worker.wait(timeout=2)
                break
            time.sleep(poll_s)
    result = {'pid': worker.pid, 'native_exitcode': worker.returncode, 'interrupted': interrupted,
              'elapsed_s': time.monotonic() - started, 'limit_s': limit_s}
    (root / 'process-receipt.json').write_text(json.dumps(result, indent=2))
    return result
