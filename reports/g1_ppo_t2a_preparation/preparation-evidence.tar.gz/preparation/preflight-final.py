import importlib.util,json,sys,time
from pathlib import Path
root=Path('/home/g1rl/g1-rl/repo');e=Path('/home/g1rl/g1-rl/evidence/t2a-frozen-policy-preparation-20261011')
spec=importlib.util.spec_from_file_location('t2_run',root/'experiments/rl/g1_ppo_t2a_frozen_comparison_001/run.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
expected=json.loads((e/'freeze-receipt-final.json').read_text())['readiness_sha256'];start=time.monotonic()
mod.verify(e/'READINESS_PROPOSAL_FINAL.json',expected)
assert 'torch' not in sys.modules and 'mujoco' not in sys.modules
receipt={'status':'NONPHYSICAL_PREFLIGHT_PASS','seconds':time.monotonic()-start,'readiness_sha256':expected,
         'acquisition_authorized':False,'physics_steps':0,'policy_loads':0,'policy_predictions':0,'optimizer_updates':0}
with (e/'preflight-receipt-final.json').open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt))
