import hashlib,importlib.util,json,sys,time
from pathlib import Path
r=Path('/home/g1rl/g1-rl/repo'); e=Path('/home/g1rl/g1-rl/evidence/t1b-ppo-optimization-20261011')
m=e/'READINESS.json'; expected=json.loads((e/'freeze-receipt.json').read_text())['readiness_sha256']
spec=importlib.util.spec_from_file_location('run',r/'experiments/rl/g1_ppo_yaw_smoke_001/run.py'); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
start=time.monotonic(); mod.verify(m,expected)
assert 'mujoco' not in sys.modules and 'torch' not in sys.modules
v={'verdict':'PASS','seconds':time.monotonic()-start,'readiness_sha256':expected,'physics_imports':False,
   'assets_verified':30,'installed_dependency_files_verified':21121,'no_install_or_download':True}
with (e/'preflight-receipt.json').open('x') as f:json.dump(v,f,indent=2)
print(json.dumps(v))
