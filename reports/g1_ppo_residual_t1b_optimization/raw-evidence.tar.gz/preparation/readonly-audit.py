import hashlib,io,json,subprocess,sys,time,zipfile
from pathlib import Path
base=Path('/home/g1rl/g1-rl/evidence/t1b-ppo-optimization-20261011'); raw=base/'acquisition-once'
start=time.monotonic(); cmd=[sys.executable,'-B','/home/g1rl/g1-rl/repo/experiments/rl/g1_ppo_yaw_smoke_001/audit.py',str(raw)]
p=subprocess.run(cmd,capture_output=True,timeout=30)
(base/'raw-audit.json').write_bytes(p.stdout); (base/'raw-audit.stderr.raw').write_bytes(p.stderr)
if p.returncode: raise SystemExit(p.returncode)
import torch
from g1swarm.residual_rl.ppo import AuditedPPO
torch.set_num_threads(1);torch.set_num_interop_threads(1)
checkpoints={}; states={}
for n in (0,128,256):
    path=raw/f'checkpoint-{n}.zip'
    with zipfile.ZipFile(path) as z:
        policy=torch.load(io.BytesIO(z.read('policy.pth')),map_location='cpu',weights_only=True)
        optimizer=torch.load(io.BytesIO(z.read('policy.optimizer.pth')),map_location='cpu',weights_only=True)
        data=json.loads(z.read('data'))
    states[n]=policy
    finite=all(torch.isfinite(v).all().item() for v in policy.values())
    optimizer_finite=all(torch.isfinite(v).all().item() for state in optimizer['state'].values() for v in state.values() if isinstance(v,torch.Tensor))
    steps=sorted({float(state['step']) for state in optimizer['state'].values()})
    tensor_hashes={k:hashlib.sha256(v.detach().cpu().contiguous().numpy().tobytes()).hexdigest() for k,v in policy.items()}
    receipt={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'num_timesteps':data['num_timesteps'],
             'optimizer_steps':data['optimizer_steps'],'epoch_updates':data['_n_updates'],
             'parameter_tensors':len(policy),'parameters_finite':finite,'optimizer_state_finite':optimizer_finite,
             'adam_parameter_states':len(optimizer['state']),'adam_step_values':steps,'tensor_sha256':tensor_hashes}
    if n:
        restored=AuditedPPO.load(path,device='cpu')
        receipt['reload_tensor_exact']=all(torch.equal(v,restored.policy.state_dict()[k]) for k,v in policy.items())
        assert receipt['reload_tensor_exact']
    assert finite and optimizer_finite
    assert data['num_timesteps']==n and data['optimizer_steps']==(0 if n==0 else n//32)
    assert steps==([] if n==0 else [float(n//32)])
    checkpoints[str(n)]=receipt
changed={f'{a}_to_{b}':[k for k,v in states[a].items() if not torch.equal(v,states[b][k])] for a,b in ((0,128),(128,256),(0,256))}
assert all(changed.values())
value={'verdict':'PASS','checkpoints':checkpoints,'changed_parameters':changed,'additional_physics_steps':0,
       'official_policy_calls':0,'residual_actor_predict_calls':0,'optimizer_calls':0,'seconds':time.monotonic()-start}
with (base/'checkpoint-audit.json').open('x') as f:json.dump(value,f,indent=2)
print(json.dumps({'raw_audit':'PASS','checkpoints':'PASS','parameter_changes':{k:len(v) for k,v in changed.items()},'seconds':value['seconds']}))
