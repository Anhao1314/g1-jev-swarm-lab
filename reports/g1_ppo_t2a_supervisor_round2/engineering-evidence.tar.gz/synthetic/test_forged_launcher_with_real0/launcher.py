import importlib.util,json,os,subprocess,sys,time,pathlib
spec=importlib.util.spec_from_file_location('sup','/home/g1rl/g1-rl/worktrees/t2a-supervisor-repair-round2/experiments/rl/g1_ppo_t2a_frozen_comparison_001/supervision.py')
sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)
root,manifest,sha='/tmp/pytest-of-g1rl/pytest-15/test_forged_launcher_with_real0/forged-run','/tmp/pytest-of-g1rl/pytest-15/test_forged_launcher_with_real0/m.json','R0'
runner='/home/g1rl/g1-rl/worktrees/t2a-supervisor-repair-round2/experiments/rl/g1_ppo_t2a_frozen_comparison_001/run.py'
os.makedirs(os.path.dirname(root),exist_ok=True);os.makedirs(root,exist_ok=True)
read_fd,write_fd=os.pipe();os.set_inheritable(read_fd,True)
nonce=os.urandom(16).hex()
open(os.path.join(root,sup.TOKEN_NAME),'w').write(nonce)
out=open(os.path.join(os.path.dirname(root),'w.out'),'wb');err=open(os.path.join(os.path.dirname(root),'w.err'),'wb')
base=[sys.executable,runner,root,manifest,sha,'--worker-owner-approved']
if 'pipe'=='stdin':
    worker=subprocess.Popen(base+['--supervisor-fd','0'],stdin=read_fd,stdout=out,stderr=err,start_new_session=True)
else:
    worker=subprocess.Popen(base+['--supervisor-fd',str(read_fd)],pass_fds=(read_fd,),stdout=out,stderr=err,start_new_session=True)
os.close(read_fd)
payload={'protocol':sup.VERSION,'run_id':str(pathlib.Path(root).resolve()),'manifest':str(pathlib.Path(manifest).resolve()),
         'readiness_sha256':sha,'execution_head':'f7398a6102b28ddb9ac36471ebce761de82e4ab1','protocol_sha256':'1181c673cf34c0886bedd68351ce6ee2baef25999097b7150a590bfba7d2e77c','nonce':nonce,
         'token':os.path.join(root,sup.TOKEN_NAME),'issued_unix':time.time(),'supervisor':sup.proc_identity(),
         'worker':sup._identity(worker.pid)}
os.write(write_fd,json.dumps(payload).encode());os.close(write_fd)
print('CHILD_RC',worker.wait())
