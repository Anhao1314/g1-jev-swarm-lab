import pathlib
pathlib.Path('/tmp/pytest-of-g1rl/pytest-15/test_direct_worker_rejected_be0/forbidden-import').write_text('imported')
raise ImportError('poisoned numpy')
