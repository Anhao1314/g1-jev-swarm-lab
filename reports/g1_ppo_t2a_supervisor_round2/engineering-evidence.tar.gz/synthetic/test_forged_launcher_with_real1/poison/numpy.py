import pathlib
pathlib.Path('/tmp/pytest-of-g1rl/pytest-15/test_forged_launcher_with_real1/forbidden-import').write_text('imported')
raise ImportError('poisoned numpy')
