import importlib.util,sys,os,subprocess,time,json
spec=importlib.util.spec_from_file_location('supervision','/home/g1rl/g1-rl/worktrees/t2a-supervisor-repair-round2/experiments/rl/g1_ppo_t2a_frozen_comparison_001/supervision.py')
sup=importlib.util.module_from_spec(spec);sys.modules['supervision']=sup;spec.loader.exec_module(sup)
fd=int(sys.argv[sys.argv.index('--supervisor-fd')+1])
def _body():
    os.set_inheritable(fd,True)
    child=subprocess.run([sys.executable,'/home/g1rl/g1-rl/worktrees/t2a-supervisor-repair-round2/experiments/rl/g1_ppo_t2a_frozen_comparison_001/run.py',sys.argv[1],sys.argv[2],sys.argv[3],'--worker-owner-approved','--supervisor-fd',str(fd)],pass_fds=(fd,))
    sys.exit(child.returncode)
try:
    _body()
except sup.DelegationRefused as exc:
    print('WORKER_REFUSED:'+str(exc),file=sys.stderr)
    raise SystemExit(76)
