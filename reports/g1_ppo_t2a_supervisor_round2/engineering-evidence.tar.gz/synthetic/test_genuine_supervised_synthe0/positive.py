import importlib.util,sys,os,subprocess,time,json
spec=importlib.util.spec_from_file_location('supervision','/home/g1rl/g1-rl/worktrees/t2a-supervisor-repair-round2/experiments/rl/g1_ppo_t2a_frozen_comparison_001/supervision.py')
sup=importlib.util.module_from_spec(spec);sys.modules['supervision']=sup;spec.loader.exec_module(sup)
fd=int(sys.argv[sys.argv.index('--supervisor-fd')+1])
def _body():
    d=sup.consume_delegation(fd,sup.entry_trust('/tmp/pytest-of-g1rl/pytest-15/test_genuine_supervised_synthe0/positive.py',sys.argv,expected_parent_argv=['/home/g1rl/g1-rl/venvs/rl/bin/python', '-B', '-m', 'pytest', '-p', 'no:cacheprovider', 'tests/test_residual_rl_t2a.py', 'tests/test_residual_rl_t2a_supervision.py', '-q']),execution_head='H0',protocol_sha256='P0')
    print('SYNTHETIC_WORKER_OK')
try:
    _body()
except sup.DelegationRefused as exc:
    print('WORKER_REFUSED:'+str(exc),file=sys.stderr)
    raise SystemExit(76)
