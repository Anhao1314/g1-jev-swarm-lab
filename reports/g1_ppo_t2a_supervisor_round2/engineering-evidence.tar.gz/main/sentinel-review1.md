REVIEW1: CHANGES_REQUIRED (read-only native Sentinel).

Full lifecycle is not bounded by an after-verifier check or pre-Popen check. Popen is not indivisible. Specify minimal Linux stdlib interruption covering synchronous preflight, setup, spawn, identity and transfer, and interruption-safe ownership/cleanup of any created process. Keep one entry-anchored 595 s cutoff and 600 s total budget.

One 250 ms group TERM grace, bounded KILL/reap, and receipt completion must fit the total deadline. Distinguish incomplete cleanup from confirmed termination. Preserve prior Worker physical failure files.

Canonical positive must carry byte-identical current run.py, supervision.py, comparison.py and unchanged protocol bytes. Exercise actual canonical argv, parent/entry/consume/claim/verify and real source/dependency/checkpoint metadata. Hash checkpoint bytes without loading. Mock downstream execution only; no expected-parent bypass or skip flags.

Required synthetic faults: stalled verifier, stalled spawn including a child created before interruption, setup/identity/transfer deadline exhaustion, cleanup/receipt deadline pressure. Assert bounded exit, no surviving owned descendants and no campaign after exhausted preflight.

Initial DeepSeek CLI stopped at the custom design coordination gate with no source edits. This failed coordination and its logs remain preserved. No approval of the initial design is claimed.
