# T2a Supervisor Repair Round2 - Forge-DS Repair Design

Baseline: f7398a6102b28ddb9ac36471ebce761de82e4ab1 (research/g1-t2a-supervisor-repair-round2).
Task class: Surgical code/lifecycle repair + test fixture repair. Authorized files (only):
supervision.py, run.py, tests/test_residual_rl_t2a_supervision.py. No science, no assets, no commit.
Baseline evidence (exact command, direct pytest): 18 failed / 80 passed; all 18 = missing
`subprocess` import in supervision.py (NameError at Popen) plus direct-supervise fixtures not
creating the campaign root. Guard bodies otherwise match PR31.

## P1 - missing import
Add `subprocess` to supervision.py imports (run.py already imports it). No other change.

## P2 - one shared lifecycle clock (595 cutoff / 600 total, cleanup reserved inside)
- run.py main records `started=time.monotonic()` at supervisor entry; derive once:
  `deadline=started+595.`, `total_deadline=started+600.` and pass all three into
  `supervise(..., started_s, deadline_s, total_deadline_s)` with the existing `limit_s=remaining`.
  No phase re-derives a fresh duration after another phase ends.
- Exhausted preflight: after `verifier(...)`, if `now>=deadline` raise
  `supervisor_cutoff_exhausted` BEFORE `root.mkdir`/`once.claim` (no campaign side effect).
- Phase bounds on the same absolute clock:
  * directory/token/pipe setup: covered by the entry-anchored deadline (no separate start).
  * spawn: Popen is one atomic syscall sequence (cannot be preempted; documented); pre-checked
    against the deadline; all failure paths covered by try/finally.
  * identity: `_identity(pid, deadline_s)` also stops retries at the deadline (200x5ms cap kept).
  * delegation transfer: `_send_payload(timeout=min(MAX_TRANSFER_S=30, deadline-now))` - a stalled
    write is bounded to 30s and can never consume a freshly restarted interval.
  * supervise loop (covers Worker validation+verify+execution, incl. the unchanged inner 590s
    worker safeguard): loop exits and sets `wall_clock_watchdog` when `now>=deadline`.
  * cleanup/reap: `_reap_group(worker, deadline_s=total_deadline)` = ONE 250ms SIGTERM grace
    window for the whole group (replacing the previous two sequential 250ms waits), then one
    bounded SIGKILL wait (GROUP_KILL_WAIT_S=2.0) and one bounded final child reap - all capped by
    total_deadline. Cleanup allowance = total_deadline-deadline = 5.0s reserved inside 600s.
  * receipt: written right after cleanup, therefore inside the total budget; `limit_s` keeps the
    remaining-at-entry semantics; add `deadline_from_entry_s`/`total_from_entry_s`/cleanup_allowance_s.
- Interruption semantics: spawn/identity/send failures close FDs in finally, write the raw
  receipt only if absent, keep the un-consumed one-shot token, and never touch Worker
  physics-failure files; timeout interrupts the supervised group (TERM then bounded KILL), so a
  Worker exit 0 or error leaves no running descendant (reap on every path).

## P3 - fixtures/module identity + canonical synthetic positive (no guard weakening)
- Identity: tests import the same module object run.py imports (`sys.path.insert(0,HERE);
  import supervision as sup`); worker fixture scripts register their file-loaded module as
  `sys.modules['supervision']` so `run.py`'s own `import supervision` reuses identical
  Delegation/EntryTrust classes and one-shot state. Direct `supervise()` tests create the
  campaign root first (mirrors production where main creates it). Expected reasons synchronized
  to actual guard messages; PR31 anchors, forged direct/pipe/stdin refusals and permit-reuse
  checks unchanged.
- NEW genuine positive: temp fixture tree carrying BYTE-IDENTICAL copies of run.py,
  supervision.py, comparison.py plus a synthetic protocol.json/manifest and a temp git repo
  (real HEAD/status checks). Launched as the canonical supervisor argv
  (`python <fixture>/run.py <campaign> <manifest> <sha> --execute-owner-approved`), so the real
  `_parent_entry_ok`/`entry_trust`/`consume_delegation`/`claim_execute`/`verify` all run with no
  `expected_parent_argv` seam, no skip/allow flags, no env/JSON authority. The Worker executes the
  real canonical run.py through the guards; only afterwards does it import a mocked
  numpy/torch/g1swarm fake execution backend (fixture PYTHONPATH) that returns deterministic
  synthetic rows/records. Asserts exit 0, all three groups written, token consumed, clean receipt.
- Negative coverage retained: real direct worker, no-FD, flag/dict copy, self-pipe+stdin forgery,
  stale/old delegation, wrong root/manifest/HEAD/protocol, exact-context single use, normal-exit
  descendant cleanup, timeout and exception cleanup/receipt.

## Validation / stopping
Run the exact two-file direct pytest command; expect the 80 prior passes preserved, the 18
repaired, and the new positive passing. Stop at green local tests; no commit/push, no acquisition.
Limitations: Popen spawn itself is atomic/not preemptible; the fake backend is synthetic mechanism
evidence only (no scientific result); receipt timing extra fields are diagnostic.
