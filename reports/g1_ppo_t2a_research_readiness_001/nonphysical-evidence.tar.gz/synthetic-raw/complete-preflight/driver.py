import importlib.util,json,sys,hashlib,os
from pathlib import Path
spec=importlib.util.spec_from_file_location('actual_run',sys.argv[1]);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def synthetic(root,m,context):
    assert not any(name in sys.modules for name in ('numpy','torch','mujoco'))
    assert context.readiness_path==str(Path(sys.argv[3]).resolve())
    Path(root,'synthetic.json').write_text(json.dumps({'actual_execution_head':m['execution_head'],'source_entries':len(m['files']),'installed_file_entries':len(m['installed_files']),'assets':len(m['assets']['files']),'dependencies':len(m['dependencies']),'heavy_imports':False,'physics':0,'inference':0,'optimizer_updates':0,'worker_pid':os.getpid(),'supervisor_pid':context.supervisor_pid}))
module.main(sys.argv[2:],executor=synthetic)
