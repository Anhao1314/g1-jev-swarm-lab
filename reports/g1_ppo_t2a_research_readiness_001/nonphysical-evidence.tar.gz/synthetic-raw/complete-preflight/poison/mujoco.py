from pathlib import Path
Path('/home/g1rl/g1-rl/evidence/t2a-readiness-selection-20261013/complete-preflight/forbidden-import').write_text('forbidden')
raise RuntimeError('forbidden import')
