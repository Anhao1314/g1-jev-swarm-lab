import pathlib
pathlib.Path('/home/g1rl/g1-rl/evidence/t2a-readiness-selection-20261013/frozen-supervision/test_direct_worker_flags_refus0/flag-1/forbidden-import').write_text('imported')
raise ImportError('poisoned torch')
