import pathlib
pathlib.Path('/home/g1rl/g1-rl/evidence/t2a-readiness-selection-20261013/baseline/test_direct_worker_flags_refus0/flag-0/forbidden-import').write_text('imported')
raise ImportError('poisoned numpy')
