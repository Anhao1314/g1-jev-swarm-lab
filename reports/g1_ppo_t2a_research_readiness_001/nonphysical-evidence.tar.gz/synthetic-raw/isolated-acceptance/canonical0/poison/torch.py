import pathlib
pathlib.Path('/home/g1rl/g1-rl/evidence/t2a-readiness-selection-20261013/isolated-acceptance/canonical0/forbidden-import').write_text('imported')
raise ImportError('poisoned torch')
