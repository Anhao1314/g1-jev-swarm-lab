import pathlib
pathlib.Path('/home/g1rl/g1-rl/evidence/t2a-readiness-selection-20261013/isolated-acceptance/test_operator_flag_required_wi0/forbidden-import').write_text('imported')
raise ImportError('poisoned numpy')
