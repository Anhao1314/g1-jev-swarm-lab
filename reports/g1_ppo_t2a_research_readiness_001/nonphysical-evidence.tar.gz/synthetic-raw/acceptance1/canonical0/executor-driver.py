import hashlib,importlib.util,json,os,sys,time
from pathlib import Path
run_path,campaign,manifest,sha=sys.argv[1:5]
kwargs={}
if len(sys.argv)>5:kwargs={'cutoff_s':float(sys.argv[5]),'total_s':float(sys.argv[6])}
spec=importlib.util.spec_from_file_location('t2_run_fixture',run_path)
module=importlib.util.module_from_spec(spec);sys.modules["t2_run_fixture"]=module;spec.loader.exec_module(module)
def executor(root,m,context):
    if os.environ.get('T2A_TEST_EXECUTOR')=='sleep':
        time.sleep(600)
    body={"verify_ran":True,"groups":sorted(m.get("checkpoints",{})),"venv_ok":m.get("venv")==sys.prefix,
          "heavy_imports":sorted(name for name in ("numpy","torch") if name in sys.modules),
          "context_type":type(context).__name__,"is_child":os.getpid()!=context.supervisor_pid,
          "manifest_sha256_matches":hashlib.sha256(Path(context.manifest_path).read_bytes()).hexdigest()==context.manifest_sha256,
          "supervisor_pid":context.supervisor_pid}
    Path(root,"synthetic-executor.json").write_text(json.dumps(body))
module.main([campaign,manifest,sha,"--execute-owner-approved"],executor=executor,**kwargs)
