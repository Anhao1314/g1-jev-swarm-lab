import hashlib,json,subprocess,sys,time
from pathlib import Path
out=Path(__file__).resolve().parent
label=sys.argv[1];tests=sys.argv[2:]
tree='/home/g1rl/g1-rl/worktrees/t2a-research-readiness-20261013'
command=['C:\\Windows\\System32\\wsl.exe','-d','G1-RL-Ubuntu','-u','g1rl','--','bash','-lc',f'cd {tree} && PYTHONPATH={tree}/src PYTHONDONTWRITEBYTECODE=1 /home/g1rl/g1-rl/venvs/rl/bin/python -B -m pytest -p no:cacheprovider '+' '.join(tests)+' -q --basetemp=/home/g1rl/g1-rl/evidence/t2a-readiness-selection-20261013/'+label]
started=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180)
log=out/(label+'.log');log.write_text(p.stdout+p.stderr,encoding='utf-8')
receipt={'argv':command,'native_exit_code':p.returncode,'elapsed_s':round(time.monotonic()-started,3),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'scope':'nonphysical synthetic tests; no model load/inference/physics','source_hashes':{}}
for name in ['run.py','supervision.py']:
    path=Path(r'\\wsl.localhost\G1-RL-Ubuntu\home\g1rl\g1-rl\worktrees\t2a-research-readiness-20261013\experiments\rl\g1_ppo_t2a_frozen_comparison_001')/name;receipt['source_hashes'][name]=hashlib.sha256(path.read_bytes()).hexdigest()
(out/(label+'.json')).write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt));print((p.stdout+p.stderr)[-4000:]);sys.exit(p.returncode)
