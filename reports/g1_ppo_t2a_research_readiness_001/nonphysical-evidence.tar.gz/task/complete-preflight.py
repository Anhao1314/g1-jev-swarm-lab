import hashlib,importlib.util,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/home/g1rl/g1-rl/worktrees/t2a-research-readiness-20261013')
out=Path('/mnt/d/webcodex/g1-t2a-readiness-evidence/20261013T1206Z')
local=Path('/home/g1rl/g1-rl/evidence/t2a-readiness-selection-20261013/complete-preflight');local.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
runfile=root/'experiments/rl/g1_ppo_t2a_frozen_comparison_001/run.py'
poison=local/'poison';poison.mkdir();marker=local/'forbidden-import'
for name in ('numpy','torch','mujoco'):
 (poison/(name+'.py')).write_text(f"from pathlib import Path\nPath({str(marker)!r}).write_text('forbidden')\nraise RuntimeError('forbidden import')\n")
env={k:v for k,v in os.environ.items() if k not in ('G1SWARM_ROOT','PYTHONHOME')};env['PYTHONPATH']=str(poison)+os.pathsep+str(root/'src');env['PYTHONDONTWRITEBYTECODE']='1'
driver=local/'driver.py';driver.write_text('''import importlib.util,json,sys,hashlib,os
from pathlib import Path
spec=importlib.util.spec_from_file_location('actual_run',sys.argv[1]);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def synthetic(root,m,context):
    assert not any(name in sys.modules for name in ('numpy','torch','mujoco'))
    assert context.readiness_path==str(Path(sys.argv[3]).resolve())
    Path(root,'synthetic.json').write_text(json.dumps({'actual_execution_head':m['execution_head'],'source_entries':len(m['files']),'installed_file_entries':len(m['installed_files']),'assets':len(m['assets']['files']),'dependencies':len(m['dependencies']),'heavy_imports':False,'physics':0,'inference':0,'optimizer_updates':0,'worker_pid':os.getpid(),'supervisor_pid':context.supervisor_pid}))
module.main(sys.argv[2:],executor=synthetic)
''')
readiness=out/'READINESS.json';original=readiness.read_bytes();m=json.loads(original)
cases=[]
def invoke(name,path,digest,flag=True,expected=None):
 args=[sys.executable,'-B',str(driver),str(runfile),str(local/name),str(path),digest]+(['--execute-owner-approved'] if flag else [])
 t=time.monotonic();p=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True,timeout=90)
 (out/(name+'.stdout')).write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr)
 receipt={'name':name,'argv':args,'native_exit_code':p.returncode,'elapsed_s':time.monotonic()-t,'stdout_sha256':sha(out/(name+'.stdout')),'stderr_sha256':sha(out/(name+'.stderr'))}
 cases.append(receipt);(out/'complete-preflight-partial.json').write_text(json.dumps(cases,indent=2))
 if expected is None:assert p.returncode==0,p.stderr
 else:assert p.returncode!=0 and expected in p.stderr,(name,p.returncode,p.stderr);assert not (local/name).exists()
 assert not marker.exists()
invoke('actual-production-synthetic',readiness,sha(readiness))
for name,change,expected in [
 ('bad-head',lambda x:x.update(execution_head='0'*40),'wrong_execution_head'),
 ('source-drift',lambda x:x['files'].update({'experiments/rl/g1_ppo_t2a_frozen_comparison_001/run.py':'0'*64}),'source_asset_drift'),
 ('bad-protocol',lambda x:x.update(protocol_sha256='0'*64),'protocol_drift')]:
 clone=json.loads(original);change(clone);path=local/(name+'.json');path.write_text(json.dumps(clone));invoke(name,path,sha(path),expected=expected)
invoke('bad-readiness',readiness,'0'*64,expected='readiness_mismatch')
invoke('missing-owner-confirmation',readiness,sha(readiness),flag=False,expected='OWNER_CONFIRMATION_REQUIRED')
assert readiness.read_bytes()==original
positive=local/'actual-production-synthetic'
receipt=json.loads((positive/'process-receipt.json').read_text());assert receipt['cleanup_complete'] and receipt['receipt_error'] is None
result={'verdict':'PASS_COMPLETE_NONPHYSICAL_PRODUCTION_ENTRY','C_exec':m['execution_head'],'readiness_sha256':sha(readiness),'cases':cases,'positive':json.loads((positive/'synthetic.json').read_text()),'process_receipt':receipt,'local_raw_directory':str(local),'readiness_input_preserved':True,'physical_authorization':False}
(out/'complete-preflight.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
