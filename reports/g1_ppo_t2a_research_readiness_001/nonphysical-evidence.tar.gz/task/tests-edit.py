from pathlib import Path
root=Path(r'\\wsl.localhost\G1-RL-Ubuntu\home\g1rl\g1-rl\worktrees\t2a-research-readiness-20261013')
p=root/'tests/test_residual_rl_t2a_supervision.py'
s=p.read_text()+'''

def test_input_readiness_is_never_replaced(tmp_path):
    result,run_dir,manifest=_run_supervised(tmp_path,'input-preserved',lambda *args:0)
    assert manifest.read_bytes()==b'{"fixture":true}'
    assert manifest.resolve()!=(run_dir/sup.MANIFEST_NAME).resolve()
    assert result['cleanup_complete']


def test_preexisting_child_is_refused_and_untouched(tmp_path):
    child=subprocess.Popen([sys.executable,'-B','-c','import time;time.sleep(30)'])
    try:
        with pytest.raises(sup.LaunchRefused,match='dedicated_supervisor_required'):
            _run_supervised(tmp_path,'shared-host',lambda *args:0)
        assert child.poll() is None
        assert not (tmp_path/'shared-host').exists()
    finally:
        child.terminate();child.wait(timeout=5)


def test_subreaper_failure_refuses_before_spawn(tmp_path,monkeypatch):
    def fail():raise OSError('subreaper_setup_failed')
    monkeypatch.setattr(sup,'_set_child_subreaper',fail)
    with pytest.raises(OSError,match='subreaper_setup_failed'):
        _run_supervised(tmp_path,'no-subreaper',lambda *args:0)
    assert not (tmp_path/'no-subreaper').exists()


def test_stalled_cleanup_is_bounded_and_failure_retained(tmp_path):
    def body(context,run_dir,manifest):time.sleep(30)
    def stall(*args):time.sleep(30)
    started=time.monotonic()
    result,run_dir,_=_run_supervised(tmp_path,'stalled-cleanup',body,
        deadline_delta=.2,total_delta=1.7,terminator=stall)
    assert time.monotonic()-started<2.2
    assert result['cleanup_complete'] is False
    assert 'DeadlineInterrupt' in result['cleanup_detail']
    assert _dead(result['pid'])
    receipt=json.loads((run_dir/sup.RECEIPT_NAME).read_text())
    assert receipt['cleanup_complete'] is False and receipt['interrupted']=='wall_clock_watchdog'


def test_stalled_receipt_cannot_report_success(tmp_path,monkeypatch,capsys):
    original=Path.write_text
    def stall(path,*args,**kwargs):
        if path.name==sup.RECEIPT_NAME:time.sleep(30)
        return original(path,*args,**kwargs)
    monkeypatch.setattr(Path,'write_text',stall)
    started=time.monotonic()
    result,run_dir,_=_run_supervised(tmp_path,'receipt-stall',lambda *args:0,
        deadline_delta=.2,total_delta=1.5)
    assert time.monotonic()-started<2.
    assert 'DeadlineInterrupt' in result['receipt_error']
    assert _dead(result['pid'])
    assert 'T2A_RECEIPT_WRITE_FAILED' in capsys.readouterr().err
    assert not (run_dir/sup.RECEIPT_NAME).exists()
'''
p.write_text(s)
