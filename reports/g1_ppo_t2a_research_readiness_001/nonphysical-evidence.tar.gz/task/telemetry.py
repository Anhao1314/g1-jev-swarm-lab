import json,subprocess,time
from pathlib import Path
out=Path('/mnt/d/webcodex/g1-t2a-readiness-evidence/20261013T1206Z');root=Path('/home/g1rl/g1-rl/worktrees/t2a-research-readiness-20261013');py='/home/g1rl/g1-rl/venvs/rl/bin/python'
receipts=[json.loads((out/(name+'.json')).read_text()) for name in ('initial','baseline','acceptance1','isolated-acceptance','final-supervision','final-comparison','frozen-supervision','frozen-comparison')]
audit=json.loads((out/'complete-preflight.json').read_text())
measures={'tests':sum(x['elapsed_s'] for x in receipts),'audit':sum(x['elapsed_s'] for x in audit['cases']),'context':.048}
records=[]
for stage,seconds in measures.items():
 p=subprocess.run([py,'-B','scripts/research_ops.py','mark','--task','t2a-readiness-selection-20261013','--stage',stage,'--label','actual_saved_receipt_duration','--seconds',str(seconds)],cwd=root,capture_output=True,text=True);records.append({'argv':p.args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0
p=subprocess.run([py,'-B','scripts/research_ops.py','summary','--task','t2a-readiness-selection-20261013'],cwd=root,capture_output=True,text=True);(out/'research-ops-summary.json').write_text(p.stdout);assert p.returncode==0
for name,args in [('context',['context']),('plan',['plan','--kind','implementation','--paths','experiments/rl/g1_ppo_t2a_frozen_comparison_001/run.py','experiments/rl/g1_ppo_t2a_frozen_comparison_001/supervision.py','tests/test_residual_rl_t2a_supervision.py']),('closeout',['closeout','--base','ec1ee7efacb2734ca69de93bb99c36da83718e08','--paths','experiments/rl/g1_ppo_t2a_frozen_comparison_001/run.py','experiments/rl/g1_ppo_t2a_frozen_comparison_001/supervision.py','tests/test_residual_rl_t2a_supervision.py'])]:
 p=subprocess.run([py,'-B','scripts/research_ops.py',*args],cwd=root,capture_output=True,text=True);(out/('research-ops-'+name+'.json')).write_text(p.stdout);assert p.returncode==0
(out/'research-ops-marks.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'measured_seconds':measures,'reasoning_implementation_tokens_cost':'unmeasured','extra_paid_API_calls':0,'physics':0,'policy_inference':0,'optimizer_updates':0}))
