import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path('/home/g1rl/g1-rl/worktrees/t2a-research-readiness-20261013')
out=Path('/mnt/d/webcodex/g1-t2a-readiness-evidence/20261013T1206Z')
old_path=Path('/home/g1rl/g1-rl/evidence/t2a-frozen-policy-preparation-20261011/READINESS_PROPOSAL_FINAL.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
write=lambda p,obj:p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
m=json.loads(old_path.read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='81f9fa9c13c167f7163dfb695d419f4be27bb773'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True).strip()
files=set(m['files'])|{'experiments/rl/g1_ppo_t2a_frozen_comparison_001/supervision.py','tests/test_residual_rl_t2a_supervision.py'}
files={p:sha(root/p) for p in sorted(files)}
source={'schema':'g1-t2a-source-freeze-v1','execution_head':head,'execution_root':str(root),'git_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'files':files,'base':'ec1ee7efacb2734ca69de93bb99c36da83718e08','original_readiness_sha256':sha(old_path)}
write(out/'SOURCE.json',source)
m.update(execution_head=head,files=files,source_manifest_sha256=sha(out/'SOURCE.json'),execution_root=str(root),acquisition_authorized=False,authorization='OWNER_CONFIRMATION_PENDING; this engineering freeze does not grant acquisition',supersedes_readiness_sha256=sha(old_path))
write(out/'READINESS.json',m)
print(json.dumps({'C_exec':head,'source_sha256':sha(out/'SOURCE.json'),'readiness_sha256':sha(out/'READINESS.json'),'protocol_sha256':m['protocol_sha256'],'files':len(files),'assets':len(m['assets']['files']),'installed_files':len(m['installed_files']),'dependencies':len(m['dependencies'])}))
write(out/'FREEZE.json',{'C_exec':head,'source_sha256':sha(out/'SOURCE.json'),'readiness_sha256':sha(out/'READINESS.json'),'protocol_sha256':m['protocol_sha256'],'acquisition_authorized':False})
