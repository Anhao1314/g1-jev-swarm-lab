from pathlib import Path
root=Path(r'\\wsl.localhost\G1-RL-Ubuntu\home\g1rl\g1-rl\worktrees\t2a-research-readiness-20261013')
p=root/'experiments/rl/g1_ppo_t2a_frozen_comparison_001/supervision.py'
s=p.read_text()
s=s.replace("        if threading.current_thread() is threading.main_thread():\n            self._saved=", "        if threading.current_thread() is not threading.main_thread():\n            _refuse('main_thread_required')\n        if threading.current_thread() is threading.main_thread():\n            self._saved=")
s=s.replace("'run_id','manifest_path','manifest_sha256'", "'run_id','readiness_path','manifest_path','manifest_sha256'")
s=s.replace('deadline_monotonic,run_inputs,seal):','deadline_monotonic,run_inputs,seal,readiness_path=None):')
s=s.replace('        self.manifest_path=manifest_path','        self.readiness_path=readiness_path\n        self.manifest_path=manifest_path')
s=s.replace('Path(manifest).resolve()!=Path(context.manifest_path)', 'Path(manifest).resolve()!=Path(context.readiness_path)')
s=s.replace("    return {pid for pid in targets if table.get(pid,{}).get('state')!='Z'}", '    return targets  # A zombie still requires waitpid; dead is not yet reaped.')
s=s.replace("    try:\n        ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)\n    except Exception:\n        pass", "    if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0:\n        raise OSError(ctypes.get_errno(),'subreaper_setup_failed')")
s=s.replace('              terminator=None,subreaper=True):','              terminator=None,subreaper=True,started_s=None):')
s=s.replace('    started=time.monotonic()\n    if deadline_s is None:', '    started=time.monotonic() if started_s is None else started_s\n    if threading.current_thread() is not threading.main_thread():\n        _refuse(\'main_thread_required\')\n    # This launcher owns a dedicated serial process, not a shared application host.\n    if _descendants(_proc_table(),os.getpid()):\n        _refuse(\'dedicated_supervisor_required\')\n    if len(os.listdir(\'/proc/self/task\'))!=1:\n        _refuse(\'single_thread_supervisor_required\')\n    if deadline_s is None:')
s=s.replace('    if subreaper:\n        _set_child_subreaper()\n    try:', '    try:')
s=s.replace('                with lifecycle_deadline(deadline_s):\n                    try:', '                with lifecycle_deadline(deadline_s):\n                    if not subreaper:_refuse(\'subreaper_required\')\n                    _set_child_subreaper()\n                    try:')
s=s.replace('context=LauncherContext(run_id=str(run_dir),manifest_path=', 'context=LauncherContext(run_id=str(run_dir),readiness_path=str(manifest_path),manifest_path=')
s=s.replace('        cleanup=_cleanup_lifecycle(owned_pid,total_deadline_s,terminator)', '''        # Reserve the last second for emergency reap and the receipt. Both cleanup
        # and receipt are interruptible, using the original entry-anchored budget.
        with lifecycle_deadline(max(time.monotonic()+1e-6,total_deadline_s-1.)):
            cleanup=_cleanup_lifecycle(owned_pid,total_deadline_s-1.,terminator)
        if owned_pid is not None and not cleanup['cleanup_complete']:
            try:
                with lifecycle_deadline(total_deadline_s-.5):
                    _signal_tree(owned_pid,signal.SIGKILL)
                    while True:
                        statuses=_reap_children()
                        if owned_pid in statuses:cleanup['worker_status']=statuses[owned_pid]
                        if not _targets_alive(owned_pid):break
                        time.sleep(GROUP_POLL_S)
            except Exception as exc:
                cleanup['cleanup_detail']+=';emergency:'+type(exc).__name__
            # Even successful emergency reap does not erase the initial failure.''')
s=s.replace("        result['receipt_error']=_write_receipt(run_dir,result,created)", "        with lifecycle_deadline(total_deadline_s):\n            result['receipt_error']=_write_receipt(run_dir,result,created)")
s=s.replace('    # as the minimal Linux subreaper. Zombies are dead for cleanup purposes.', '    # as the minimal Linux subreaper. Zombies must also be reaped.')
p.write_text(s)
p=root/'experiments/rl/g1_ppo_t2a_frozen_comparison_001/run.py';s=p.read_text().replace('deadline_s=deadline,total_deadline_s=total_deadline)', 'deadline_s=deadline,total_deadline_s=total_deadline,started_s=started)').replace('Path(context.manifest_path),context.readiness_sha256','Path(context.readiness_path),context.readiness_sha256');p.write_text(s)
p=root/'tests/test_residual_rl_t2a_supervision.py';s=p.read_text()
a=s.index('        def body(context,run_dir,manifest):', s.index('def test_signal_during_supervise'))
b=s.index("        assert result['interrupted']",a)
s=s[:a]+'''        def body(context,run_dir,manifest):
            os.kill(context.supervisor_pid,signum)
            time.sleep(30.);return 0
        result,run_dir,manifest=_run_supervised(tmp_path,'signal-'+signal.Signals(signum).name,body)
'''+s[b:]
s=s.replace('    assert set(lines)==ALLOWED_MODIFIED','    assert set(lines)<=ALLOWED_MODIFIED  # also valid on the clean frozen execution commit')
p.write_text(s)
print('edited only 3 allowed files')
