from pathlib import Path
root=Path(r'\\wsl.localhost\G1-RL-Ubuntu\home\g1rl\g1-rl\worktrees\t2a-research-readiness-20261013')
p=root/'experiments/rl/g1_ppo_t2a_frozen_comparison_001/supervision.py';s=p.read_text()
s=s.replace('''        with lifecycle_deadline(max(time.monotonic()+1e-6,total_deadline_s-1.)):
            cleanup=_cleanup_lifecycle(owned_pid,total_deadline_s-1.,terminator)''','''        try:
            with lifecycle_deadline(total_deadline_s-1.):
                cleanup=_cleanup_lifecycle(owned_pid,total_deadline_s-1.,terminator)
        except BaseException as exc:
            cleanup={'cleanup_complete':False,'cleanup_detail':f'{type(exc).__name__}:{exc}',
                     'worker_status':None}''')
a=s.index('        with lifecycle_deadline(total_deadline_s):\n            result[\'receipt_error\']')
b=s.index('    if failure is not None:\n        raise failure',a)
s=s[:a]+'''        try:
            with lifecycle_deadline(total_deadline_s):
                result['receipt_error']=_write_receipt(run_dir,result,created)
        except BaseException as exc:
            result['receipt_error']=f'{type(exc).__name__}:{exc}'
        finally:
            if lock_fd is not None:
                try:os.close(lock_fd)
                except OSError:pass
            if installed:
                for signum,handler in previous_handlers.items():
                    signal.signal(signum,handler)
        if result['receipt_error'] is not None:
            # External invocation captures stderr if the filesystem cannot retain a receipt.
            print('T2A_PROCESS_RECEIPT_FAILURE:'+json.dumps(result,sort_keys=True),file=sys.stderr,flush=True)
'''+s[b:]
p.write_text(s)
p=root/'tests/test_residual_rl_t2a_supervision.py';s=p.read_text()+'''

@pytest.mark.parametrize('mode',['raise','stall'])
def test_outer_cleanup_exception_still_reaps_and_records(tmp_path,monkeypatch,mode):
    def broken(*args):
        if mode=='stall':time.sleep(30)
        raise RuntimeError('outer_cleanup_fault')
    monkeypatch.setattr(sup,'_cleanup_lifecycle',broken)
    previous={signum:signal.getsignal(signum) for signum in (signal.SIGTERM,signal.SIGINT)}
    result,run_dir,_=_run_supervised(tmp_path,'outer-'+mode,lambda *args:time.sleep(30),
        deadline_delta=.2,total_delta=1.7)
    assert result['cleanup_complete'] is False and _dead(result['pid'])
    assert ('DeadlineInterrupt' if mode=='stall' else 'outer_cleanup_fault') in result['cleanup_detail']
    assert json.loads((run_dir/sup.RECEIPT_NAME).read_text())['cleanup_complete'] is False
    assert all(signal.getsignal(s)==h for s,h in previous.items())
''';p.write_text(s)
print('single concentrated audit correction applied')
