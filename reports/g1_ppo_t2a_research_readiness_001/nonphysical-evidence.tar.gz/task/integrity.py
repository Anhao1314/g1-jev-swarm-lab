import hashlib,json,subprocess,time
from pathlib import Path
root=Path('/home/g1rl/g1-rl/worktrees/t2a-research-readiness-20261013');out=Path('/mnt/d/webcodex/g1-t2a-readiness-evidence/20261013T1206Z')
base='ec1ee7efacb2734ca69de93bb99c36da83718e08'
prefix='experiments/rl/g1_ppo_t2a_frozen_comparison_001/'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=root)
current=(root/prefix/'run.py').read_bytes();old=git('show',base+':'+prefix+'run.py')
science=lambda b:b[b.index(b'    import numpy as np'):b.index(b'    finally:ledger.close()')+len(b'    finally:ledger.close()')]
verify=lambda b:b[b.index(b'def verify('):b.index(b'\ndef execute(')]
assert science(current)==science(old),'science_changed'
assert verify(current)==verify(old),'verifier_changed'
allowed={prefix+'run.py',prefix+'supervision.py','tests/test_residual_rl_t2a_supervision.py'}
assert set(git('diff','--name-only',base).decode().splitlines())==allowed
original=Path('/home/g1rl/g1-rl/worktrees/t2a-execution-simplification')
snapshot=json.loads((out/'prepare-receipt.json').read_text()); print(json.dumps(snapshot)[:1800])
old_readiness=Path('/home/g1rl/g1-rl/evidence/t2a-frozen-policy-preparation-20261011/READINESS_PROPOSAL_FINAL.json')
m=json.loads(old_readiness.read_text());print('READINESS_KEYS',list(m))
source_diff=[]
for path,h in m['files'].items():
 if sha(root/path)!=h:source_diff.append(path)
assert set(source_diff)<=allowed,source_diff
receipt={'status':'PASS','base':base,'science_body_sha256':hashlib.sha256(science(current)).hexdigest(),'verifier_sha256':hashlib.sha256(verify(current)).hexdigest(),'changed_paths':sorted(allowed),'changed_since_old_readiness':source_diff,'unchanged_history_and_ops':'all other tracked paths identical to base','prior_readiness_sha256':sha(old_readiness),'source_entries':len(m['files']),'installed_file_entries':len(m['installed_files']),'dependencies':len(m['dependencies']),'official_assets':len(m['assets']['files']),'nonphysical':True}
(out/'integrity-before-commit.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(receipt))
