import hashlib,json,shutil,subprocess
from pathlib import Path
prior=Path('/home/g1rl/g1-rl/worktrees/t2a-execution-simplification')
root=Path('/home/g1rl/g1-rl/worktrees/t2a-research-readiness-20261013')
out=Path('/mnt/d/webcodex/g1-t2a-readiness-evidence/20261013T1206Z')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
targets=['experiments/rl/g1_ppo_t2a_frozen_comparison_001/run.py','experiments/rl/g1_ppo_t2a_frozen_comparison_001/supervision.py','tests/test_residual_rl_t2a_supervision.py']
snapshot=out/'prior-worktree';snapshot.mkdir()
records={}
for name in targets+['scratch_ap_test.txt']:
    p=prior/name;q=snapshot/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);records[name]=sha(p);assert sha(q)==sha(p)
(snapshot/'uncommitted.diff').write_bytes(subprocess.check_output(['git','-C',str(prior),'diff','--binary']))
head=subprocess.check_output(['git','-C',str(prior),'rev-parse','HEAD'],text=True).strip()
assert head=='ec1ee7efacb2734ca69de93bb99c36da83718e08'
subprocess.run(['git','-C','/home/g1rl/g1-rl/repo','worktree','add','-b','research/g1-t2a-research-readiness',str(root),head],check=True)
for name in targets:shutil.copy2(prior/name,root/name)
old=Path('/home/g1rl/g1-rl/evidence/t2a-frozen-policy-preparation-20261011/READINESS_PROPOSAL_FINAL.json')
assert sha(old)=='cf0d476290a9e7bb5740f8503fc30fd29a3b1d309bf954fb666517f11564aadc'
assets={p:h for p,h in json.loads(old.read_text())['files'].items() if p.startswith('third_party/')}
for name,h in assets.items():
    p=prior/name;assert sha(p)==h;q=root/name
    if not q.exists():q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
    assert sha(q)==h
receipt={'prior_head':head,'prior_root':str(prior),'work_root':str(root),'preserved_files':records,'prior_diff_sha256':sha(snapshot/'uncommitted.diff'),'verified_asset_count':len(assets),'science':{'physics':0,'policy_loads':0,'training':0},'historical_readiness_sha256':sha(old)}
(out/'prepare-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
