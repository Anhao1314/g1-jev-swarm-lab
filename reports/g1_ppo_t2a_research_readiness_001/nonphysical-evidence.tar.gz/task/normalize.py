from pathlib import Path
root=Path(r'\\wsl.localhost\G1-RL-Ubuntu\home\g1rl\g1-rl\worktrees\t2a-research-readiness-20261013')
for name in ['experiments/rl/g1_ppo_t2a_frozen_comparison_001/run.py','experiments/rl/g1_ppo_t2a_frozen_comparison_001/supervision.py','tests/test_residual_rl_t2a_supervision.py']:
 p=root/name;b=p.read_bytes();print(name,len(b),b.count(b'\r\n'));p.write_bytes(b.replace(b'\r\n',b'\n'))
