from pathlib import Path
p=Path(r'D:\webcodex\g1-t2a-readiness-evidence\20261013T1206Z\integrity.py')
s=p.read_text(encoding='utf-8-sig').replace("assert set(source_diff)<=allowed,source_diff", "inherited={prefix+'comparison.py','tests/test_residual_rl_t2a.py'}\nassert set(source_diff)<=allowed|inherited,source_diff\nfor path in inherited:\n assert (root/path).read_bytes()==git('show',base+':'+path),'inherited_classifier_changed'\nfor path,h in snapshot['preserved_files'].items():\n assert sha(original/path)==h,'original_worktree_changed:'+path")
p.with_name('integrity-v2.py').write_text(s,encoding='utf-8')
