import json,subprocess,sys,time
from pathlib import Path
base=Path('/home/g1rl/g1-rl/evidence/t1-ppo-smoke-20261011')
start=time.monotonic(); cmd=[sys.executable,'-B','/home/g1rl/g1-rl/repo/experiments/rl/g1_ppo_yaw_smoke_001/audit_partial.py',str(base/'acquisition-once')]
p=subprocess.run(cmd,capture_output=True,timeout=30)
(base/'partial-audit.json').write_bytes(p.stdout); (base/'partial-audit.stderr.raw').write_bytes(p.stderr)
(base/'partial-audit-receipt.json').write_text(json.dumps({'command':cmd,'native_exitcode':p.returncode,'seconds':time.monotonic()-start},indent=2))
if p.returncode: print(p.stderr.decode()); raise SystemExit(p.returncode)
v=json.loads(p.stdout); print(json.dumps({k:v[k] for k in ('integrity_verdict','scientific_verdict','check_count','native_by_stage','train_interactions','optimizer_updates')}))
