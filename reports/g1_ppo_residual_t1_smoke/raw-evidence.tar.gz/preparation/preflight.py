import copy,hashlib,importlib.util,json,os,sys,time,traceback
from pathlib import Path
base=Path('/home/g1rl/g1-rl/evidence/t1-ppo-smoke-20261011')
r=Path('/home/g1rl/g1-rl/repo')
spec=importlib.util.spec_from_file_location('t1_run',r/'experiments/rl/g1_ppo_yaw_smoke_001/run.py'); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
f=base/'execution-freeze-final.json'; expected='fdbfeea34fbe76e9bbdb52722dd957e6f56ca5c6f13b8904f30f5336ff5e71b9'
start=time.monotonic(); checks={}; original=json.loads(f.read_text())
mod.verify(f,expected); checks['correct_full_identity']='PASS'
try: mod.verify(f,'0'*64)
except RuntimeError as exc: checks['wrong_readiness_rejected']=str(exc)
for name,mutate in [('head',lambda m:m.update(execution_head='0'*40)),('source',lambda m:m['files'].update({'src/g1swarm/control/path_correction.py':'0'*64})),('dependency',lambda m:m['dependencies'].update({'torch':'0.0.0'}))]:
    data=copy.deepcopy(original); mutate(data); bad=base/f'nonphysical-wrong-{name}.json'
    with bad.open('x') as out: json.dump(data,out,sort_keys=True)
    try: mod.verify(bad,hashlib.sha256(bad.read_bytes()).hexdigest())
    except RuntimeError as exc: checks[f'wrong_{name}_rejected']=str(exc)
    else: raise AssertionError(name+' not refused')
checks['no_mujoco_import']='mujoco' not in sys.modules
checks['no_torch_import']='torch' not in sys.modules
receipt={'verdict':'PASS','checks':checks,'seconds':time.monotonic()-start,'expected_sha256':expected}
with (base/'final-preflight.json').open('x') as out: json.dump(receipt,out,indent=2)
print(json.dumps(receipt))
