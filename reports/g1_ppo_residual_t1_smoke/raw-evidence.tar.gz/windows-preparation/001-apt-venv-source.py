from pathlib import Path
import subprocess,json,hashlib,time,os
out=Path('/home/g1rl/g1-rl/evidence/t1-ppo-smoke-20261011');out.mkdir(exist_ok=False)
lock=json.loads(Path('/home/g1rl/g1-rl/evidence/recovery-03-full-apt-20261011/013-apt-lock.json').read_text())
args=lock['exact_version_arguments']
for attempt in range(3):
 command=['/usr/bin/apt-get','--download-only','--yes','--no-install-recommends','-o','Acquire::Retries=0','-o','Acquire::http::Timeout=60','-o','Acquire::https::Timeout=60','install',*args]
 t=time.monotonic()
 with (out/('apt-download-'+str(attempt)+'.stdout.raw')).open('xb') as so,(out/('apt-download-'+str(attempt)+'.stderr.raw')).open('xb') as se:
  r=subprocess.run(command,stdout=so,stderr=se,timeout=300)
 with (out/('apt-download-'+str(attempt)+'.json')).open('x') as f:json.dump({'argv':command,'returncode':r.returncode,'elapsed_seconds':time.monotonic()-t,'attempt':attempt},f,indent=2)
 if r.returncode==0:break
 if attempt==2:raise RuntimeError('APT bounded downloads exhausted')
verified=[]
for item in lock['selected_packages']:
 path=Path('/var/cache/apt/archives')/item['cache_filename'];b=path.read_bytes()
 if len(b)!=item['bytes'] or hashlib.sha256(b).hexdigest()!=item['sha256']:raise RuntimeError('APT locked hash mismatch '+item['package'])
 verified.append(item)
with (out/'apt-download-verified.json').open('x') as f:json.dump(verified,f,indent=2)
command=['/usr/bin/apt-get','--no-download','--yes','--no-install-recommends','install',*args]
with (out/'apt-install.stdout.raw').open('xb') as so,(out/'apt-install.stderr.raw').open('xb') as se:r=subprocess.run(command,stdout=so,stderr=se,timeout=180,env={**os.environ,'DEBIAN_FRONTEND':'noninteractive','LC_ALL':'C'})
with (out/'apt-install.json').open('x') as f:json.dump({'argv':command,'returncode':r.returncode,'all_deb_hashes_verified':True},f,indent=2)
if r.returncode:raise RuntimeError('APT install failed')
venv=Path('/home/g1rl/g1-rl/venvs/rl')
if venv.exists():raise RuntimeError('Venv exists; no overwrite')
subprocess.run(['/usr/bin/python3','-m','venv',str(venv)],check=True,timeout=60)
repo=Path('/home/g1rl/g1-rl/repo')
if repo.exists():raise RuntimeError('Repo exists; no overwrite')
for attempt in range(3):
 target=repo if attempt==0 else Path(str(repo)+'-clone-attempt-'+str(attempt))
 with (out/('git-clone-'+str(attempt)+'.stdout.raw')).open('xb') as so,(out/('git-clone-'+str(attempt)+'.stderr.raw')).open('xb') as se:
  r=subprocess.run(['/usr/bin/git','clone','--no-checkout','https://github.com/Anhao1314/g1-jev-swarm-lab',str(target)],stdout=so,stderr=se,timeout=240,env={**os.environ,'GIT_LFS_SKIP_SMUDGE':'1','GIT_TERMINAL_PROMPT':'0'})
 if r.returncode==0:
  if attempt:target.rename(repo)
  break
 if attempt==2:raise RuntimeError('Git clone bounded download exhausted')
subprocess.run(['/usr/bin/git','checkout','--detach','e1ddd31978779365634989684579587668a56e7d'],cwd=repo,check=True,timeout=30)
subprocess.run(['/usr/bin/git','switch','-c','research/g1-ppo-residual-t1-smoke'],cwd=repo,check=True,timeout=30)
print(json.dumps({'apt_packages_verified':len(verified),'venv':str(venv),'repo':str(repo),'head':subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=repo).decode().strip()}))
