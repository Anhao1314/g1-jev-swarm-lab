from pathlib import Path
import urllib.request,html,re,json,subprocess,time,hashlib,zipfile,email,os
out=Path('/home/g1rl/g1-rl/evidence/t1-ppo-smoke-20261011');venv=Path('/home/g1rl/g1-rl/venvs/rl');wheels=out/'wheelhouse';wheels.mkdir(exist_ok=True)
index='https://download.pytorch.org/whl/cpu/torch/'
text=(out/'torch-cpu-index.html').read_text()
urls=[html.unescape(u) for u in re.findall(r'href="([^"]+)"',text) if 'torch-2.14.1%2Bcpu-cp312-cp312-manylinux_2_28_x86_64.whl' in u or 'torch-2.14.1+cpu-cp312-cp312-manylinux_2_28_x86_64.whl' in u]
if len(urls)!=1:raise RuntimeError('Exact CPU wheel identity not unique')
torch_url=urls[0]
requirements=[torch_url,'mujoco==3.15.0','gymnasium==1.4.0','stable-baselines3==2.9.0','numpy==2.4.6','PyYAML==6.0.3','lark==1.3.1','pytest==8.4.2','pip==24.0','setuptools==77.0.3']
command=[str(venv/'bin/python'),'-m','pip','--disable-pip-version-check','download','--index-url','https://pypi.org/simple','--only-binary=:all:','--retries','2','--timeout','60','--dest',str(wheels),*requirements]
with (out/'pip-download-compat.stdout.raw').open('xb') as so,(out/'pip-download-compat.stderr.raw').open('xb') as se:r=subprocess.run(command,stdout=so,stderr=se,timeout=600)
with (out/'pip-download-compat.json').open('x') as f:json.dump({'argv':command,'returncode':r.returncode,'bounded_network_retries':2,'torch_source':torch_url},f,indent=2)
if r.returncode:raise RuntimeError('PIP trusted wheel download failed')
lock=[]
for path in sorted(wheels.glob('*.whl')):
 with zipfile.ZipFile(path) as z:
  meta=email.message_from_bytes(z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))))
 name,version=meta['Name'],meta['Version'];digest=hashlib.sha256(path.read_bytes()).hexdigest()
 if name.lower().startswith(('nvidia','cuda','triton')):raise RuntimeError('Unexpected GPU dependency '+name)
 source='PyPI official wheel source'
 if name.lower()!='torch':
  for metadata_attempt in range(3):
   try:
    with urllib.request.urlopen('https://pypi.org/pypi/'+name+'/'+version+'/json',timeout=60) as response: info=json.loads(response.read())
    break
   except Exception:
    if metadata_attempt==2:raise
  entry=next(x for x in info['urls'] if x['filename']==path.name)
  if entry['digests']['sha256']!=digest:raise RuntimeError('PyPI expected hash mismatch '+name)
  source=entry['url']
 if name.lower()=='torch':
  expected=torch_url.split('#sha256=')[1]
  if digest!=expected:raise RuntimeError('Torch CPU source hash mismatch')
  source=torch_url
 lock.append({'name':name,'version':version,'filename':path.name,'bytes':path.stat().st_size,'sha256':digest,'source':source})
with (out/'python-wheel-lock.json').open('x') as f:json.dump(lock,f,indent=2)
locktext='\n'.join(x['name']+'=='+x['version']+' --hash=sha256:'+x['sha256'] for x in lock)+'\n'
with (out/'requirements.lock').open('x') as f:f.write(locktext)
command=[str(venv/'bin/python'),'-m','pip','--disable-pip-version-check','install','--no-index','--find-links',str(wheels),'--only-binary=:all:','--require-hashes','--force-reinstall','-r',str(out/'requirements.lock')]
with (out/'pip-install.stdout.raw').open('xb') as so,(out/'pip-install.stderr.raw').open('xb') as se:r=subprocess.run(command,stdout=so,stderr=se,timeout=180)
with (out/'pip-install.json').open('x') as f:json.dump({'argv':command,'returncode':r.returncode,'wheel_count':len(lock)},f,indent=2)
if r.returncode:raise RuntimeError('Hashed offline install failed')
subprocess.run([str(venv/'bin/python'),'-m','pip','check'],check=True,timeout=30)
for root in ['/home/g1rl/g1-rl/repo','/home/g1rl/g1-rl/venvs/rl','/home/g1rl/g1-rl/evidence/t1-ppo-smoke-20261011']:
 for directory,dirs,files in os.walk(root):
  os.chown(directory,1000,1000)
  for filename in files:os.chown(os.path.join(directory,filename),1000,1000)
print(json.dumps({'wheel_count':len(lock),'torch':'2.14.1+cpu','mujoco':'3.15.0','installed':True}))
